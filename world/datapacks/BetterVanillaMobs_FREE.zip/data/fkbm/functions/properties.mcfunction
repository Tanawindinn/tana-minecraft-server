### Better Vanilla Mobs Datapack
###
### Developped by FunkyToc
### With love
### And a big amount of time


### CONFIG


## Performances

# Base difficulty of the overhauled mobs of the pack
# Default: 4
# 0: peacefull
# 1: easy
# 2: normal
# 3: hard
# 4: auto (same as world difficulty)
execute unless score BaseDifficulty fkbm.options matches 0.. run scoreboard players set BaseDifficulty fkbm.options 4

# Loop frequency in seconds to update mob's statistics (low value use more CPU)
# Default: 5
# Range: 1 - 30
execute unless score MobModifyFrequency fkbm.options matches 0.. run scoreboard players set MobModifyFrequency fkbm.options 5

# Loop frequency in seconds to update baby's statistics wich are now adults (low value use more CPU)
# Default: 30
# Range: 1 - 300
execute unless score BabyMobModifyFrequency fkbm.options matches 0.. run scoreboard players set BabyMobModifyFrequency fkbm.options 120

# Loop frequency in seconds for mob's behavior and global gameplay reactivity (low value use more CPU)
# Default: 1
# Range: 1 - 10
execute unless score MobGameplayLatency fkbm.options matches 0.. run scoreboard players set MobGameplayLatency fkbm.options 1


## Selections

# Modify mobs in the Overworld
# Default: 1
# 0: disabled
# 1: enabled
execute unless score OverTouch fkbm.options matches 0.. run scoreboard players set OverTouch fkbm.options 1

# Modify mobs in the Nether
# Default: 1
# 0: disabled
# 1: enabled
execute unless score NetherTouch fkbm.options matches 0.. run scoreboard players set NetherTouch fkbm.options 1

# Modify mobs in the End
# Default: 1
# 0: disabled
# 1: enabled
execute unless score EndTouch fkbm.options matches 0.. run scoreboard players set EndTouch fkbm.options 1


## FX

# Play some sounds on events
# Default: 1
# 0: disabled
# 1: enabled
execute unless score Sounds fkbm.options matches 0.. run scoreboard players set Sounds fkbm.options 1



### GLOBAL

# Allow player to recover in ground arrows from mobs
# Default: 1
# 0: disabled
# 1: enabled
execute unless score EntityArrowPickup fkbm.options matches 0.. run scoreboard players set EntityArrowPickup fkbm.options 1

# Rename ALPHA mob variants with red skulls
# Default: 1
# 0: disabled
# 1: enabled
execute unless score RenameAlphaMobs fkbm.options matches 0.. run scoreboard players set RenameAlphaMobs fkbm.options 1



### MOBS


## CAVE SPIDER

# Enable Cave spider modification
# Default: 1
# 0: disabled
# 1: enabled
execute unless score CavespiderTouch fkbm.options matches 0.. run scoreboard players set CavespiderTouch fkbm.options 1

# Allow Cave spiders to stick to the ceiling
# Default: 1
# 0: disabled
# 1: enabled
execute unless score CavespiderCeiling fkbm.options matches 0.. run scoreboard players set CavespiderCeiling fkbm.options 1

# Cave spiders bites give quick nausea and slowness effects
# Default: 1
# 0: disabled
# 1: enabled
execute unless score CavespiderNausea fkbm.options matches 0.. run scoreboard players set CavespiderNausea fkbm.options 1


## CREEPER

# Enable Creeper modification
# Default: 1
# 0: disabled
# 1: enabled
execute unless score CreeperTouch fkbm.options matches 0.. run scoreboard players set CreeperTouch fkbm.options 1

# Gives some creepers a sound bait ability
# Default: 1
# 0: disabled
# 1: enabled
execute unless score CreeperBait fkbm.options matches 0.. run scoreboard players set CreeperBait fkbm.options 1

# Randomize the fuse timer of creepers
# Default: 1
# 0: disabled
# 1: enabled
execute unless score CreeperRandomFuse fkbm.options matches 0.. run scoreboard players set CreeperRandomFuse fkbm.options 1

# Randomize the explosion radius of creepers
# Default: 1
# 0: disabled
# 1: enabled
execute unless score CreeperRandomExplosionRadius fkbm.options matches 0.. run scoreboard players set CreeperRandomExplosionRadius fkbm.options 1

# Allow some creepers to explode instantly on damage
# Default: 1
# 0: disabled
# 1: enabled
execute unless score CreeperUnstable fkbm.options matches 0.. run scoreboard players set CreeperUnstable fkbm.options 1

# Allow some creepers to become a powerful ALPHA
# Default: 1
# 0: disabled
# 1: enabled
execute unless score CreeperAlpha fkbm.options matches 0.. run scoreboard players set CreeperAlpha fkbm.options 1

# Chances per creepers to become an ALPHA (in %)
# Default: 5
# Range: 0 - 100
execute unless score CreeperAlphaChance fkbm.options matches 0.. run scoreboard players set CreeperAlphaChance fkbm.options 5


## DROWNED

# Enable Drowned modification
# Default: 1
# 0: disabled
# 1: enabled
execute unless score DrownedTouch fkbm.options matches 0.. run scoreboard players set DrownedTouch fkbm.options 1

# Allow some drowned to slow down player in water on hit
# Default: 1
# 0: disabled
# 1: enabled
execute unless score DrownedHitslow fkbm.options matches 0.. run scoreboard players set DrownedHitslow fkbm.options 1


## ENDERMAN

# Enable Enderman modification
# Default: 1
# 0: disabled
# 1: enabled
execute unless score EndermanTouch fkbm.options matches 0.. run scoreboard players set EndermanTouch fkbm.options 1

# Allow some endermans to freeze player with battle eyes (1.19+)
# Default: 1
# 0: disabled
# 1: enabled
execute unless score EndermanLookfreeze fkbm.options matches 0.. run scoreboard players set EndermanLookfreeze fkbm.options 1

# Allow some endermans to teleport players into their vortex
# Default: 1
# 0: disabled
# 1: enabled
execute unless score EndermanVortex fkbm.options matches 0.. run scoreboard players set EndermanVortex fkbm.options 1

# Allow some endermans to break blocks infront of their heads when chasing a player
# Default: 1
# 0: disabled
# 1: enabled
execute unless score EndermanLookbreak fkbm.options matches 0.. run scoreboard players set EndermanLookbreak fkbm.options 1


## EVOKER

# Enable Evoker modification
# Default: 1
# 0: disabled
# 1: enabled
execute unless score EvokerTouch fkbm.options matches 0.. run scoreboard players set EvokerTouch fkbm.options 1

# Allow some Evokers to heal nearby allies
# Default: 1
# 0: disabled
# 1: enabled
execute unless score EvokerGroupHeal fkbm.options matches 0.. run scoreboard players set EvokerGroupHeal fkbm.options 1

# Evokers healing skill cooldown (seconds)
# Default: 30
# Range: 1 - 999
execute unless score EvokerGroupHealCd fkbm.options matches 0.. run scoreboard players set EvokerGroupHealCd fkbm.options 30

# Allow some Evokers to soft root nearby players
# Default: 1
# 0: disabled
# 1: enabled
execute unless score EvokerRoot fkbm.options matches 0.. run scoreboard players set EvokerRoot fkbm.options 1

# Evokers root skill cooldown (seconds)
# Default: 6
# Range: 1 - 999
execute unless score EvokerRootCd fkbm.options matches 0.. run scoreboard players set EvokerRootCd fkbm.options 6


## HOGLIN

# Enable Hoglin modification
# Default: 1
# 0: disabled
# 1: enabled
execute unless score HoglinTouch fkbm.options matches 0.. run scoreboard players set HoglinTouch fkbm.options 1

# Allow some hoglins to be immune to zombification
# Default: 1
# 0: disabled
# 1: enabled
execute unless score HoglinHotblood fkbm.options matches 0.. run scoreboard players set HoglinHotblood fkbm.options 1

# Allow some hoglins to stomp nearby players
# Default: 1
# 0: disabled
# 1: enabled
execute unless score HoglinStomp fkbm.options matches 0.. run scoreboard players set HoglinStomp fkbm.options 1

# Stomp ability skill's cooldown
# Default: 15
# Range: 0 - 100
execute unless score HoglinStompCd fkbm.options matches 0.. run scoreboard players set HoglinStompCd fkbm.options 15

# Allow some hoglins to become a powerful ALPHA
# Default: 1
# 0: disabled
# 1: enabled
execute unless score HoglinAlpha fkbm.options matches 0.. run scoreboard players set HoglinAlpha fkbm.options 1

# Chances per hoglins to become an ALPHA (in %)
# Default: 5
# Range: 0 - 100
execute unless score HoglinAlphaChance fkbm.options matches 0.. run scoreboard players set HoglinAlphaChance fkbm.options 5


## HUSK

# Enable Husk modification
# Default: 1
# 0: disabled
# 1: enabled
execute unless score HuskTouch fkbm.options matches 0.. run scoreboard players set HuskTouch fkbm.options 1

# Allow some husks to break torches
# Default: 1
# 0: disabled
# 1: enabled
execute unless score HuskBreakTorch fkbm.options matches 0.. run scoreboard players set HuskBreakTorch fkbm.options 1

# Allow some husks to break wooden doors instantly (regardless of the difficulty)
# Default: 1
# 0: disabled
# 1: enabled
execute unless score HuskBreakDoor fkbm.options matches 0.. run scoreboard players set HuskBreakDoor fkbm.options 1

# Allow some husks to break wooden fences instantly (regardless of the difficulty)
# Default: 1
# 0: disabled
# 1: enabled
execute unless score HuskBreakFence fkbm.options matches 0.. run scoreboard players set HuskBreakFence fkbm.options 1

# Allow some husk to slow down player on hit, and buff nearby husks
# Default: 1
# 0: disabled
# 1: enabled
execute unless score HuskHitslow fkbm.options matches 0.. run scoreboard players set HuskHitslow fkbm.options 1

# Cooldown loop regen: +2  hearts every (N x MobGameplayLatency) seconds
# Default: N = 4 (means every 4 x 1 = 4 seconds)
# 0: disabled
# 1+: enabled, N = 1+
execute unless score HuskPassiveRegenCd fkbm.options matches 0.. run scoreboard players set HuskPassiveRegenCd fkbm.options 4


## ILLUSIONER

# Enable illusioner modification
# Default: 1
# 0: disabled
# 1: enabled
execute unless score IllusionerTouch fkbm.options matches 0.. run scoreboard players set IllusionerTouch fkbm.options 1

# Illusioner spawn chance (in %) on target hit near a Pillager Outpost
# Default: 10
# Range: 0 - 100
execute unless score IllusionerSpawnChance fkbm.options matches 0.. run scoreboard players set IllusionerSpawnChance fkbm.options 10

# Some illusioner have powerfull bows
# Default: 1
# 0: disabled
# 1: enabled
execute unless score IllusionerEnchantedBow fkbm.options matches 0.. run scoreboard players set IllusionerEnchantedBow fkbm.options 1

# Heal spell cooldown in seconds
# Default: 20
# Range: 1 - 999
execute unless score IllusionerHealCd fkbm.options matches 0.. run scoreboard players set IllusionerHealCd fkbm.options 20

# Some illusioner have lower cooldown on spell cast (also affects heal cooldown)
# Default: 1
# 0: disabled
# 1: enabled
execute unless score IllusionerCdBuff fkbm.options matches 0.. run scoreboard players set IllusionerCdBuff fkbm.options 1


## PILLAGER

# Enable Pillager modification
# Default: 1
# 0: disabled
# 1: enabled
execute unless score PillagerTouch fkbm.options matches 0.. run scoreboard players set PillagerTouch fkbm.options 1

# Allow some Pillagers to get Multishot enchantment
# Default: 1
# 0: disabled
# 1: enabled
execute unless score PillagerMultishot fkbm.options matches 0.. run scoreboard players set PillagerMultishot fkbm.options 1

# Allow some Pillagers to get QuickCharge enchantment
# Default: 1
# 0: disabled
# 1: enabled
execute unless score PillagerQuickCharge fkbm.options matches 0.. run scoreboard players set PillagerQuickCharge fkbm.options 1

# Allow some Pillagers to shot firework rockets
# Default: 1
# 0: disabled
# 1: enabled
execute unless score PillagerFireworkRocket fkbm.options matches 0.. run scoreboard players set PillagerFireworkRocket fkbm.options 1

# Firework rockets reload cooldown (it will be divided by the difficulty)
# Default: 20
# 0 : no cooldown / always up
# Range: 0 - 100
execute unless score PillagerFireworkRocketCd fkbm.options matches 0.. run scoreboard players set PillagerFireworkRocketCd fkbm.options 20


## POLAR BEAR

# Enable Polarbear modification
# Default: 1
# 0: disabled
# 1: enabled
execute unless score PolarbearTouch fkbm.options matches 0.. run scoreboard players set PolarbearTouch fkbm.options 1

# Makes polar bears angry on player close range
# Default: 1
# 0: disabled
# 1: enabled
execute unless score PolarbearAngry fkbm.options matches 0.. run scoreboard players set PolarbearAngry fkbm.options 1


## SLIME

# Enable Slime modification
# Default: 1
# 0: disabled
# 1: enabled
execute unless score SlimeTouch fkbm.options matches 0.. run scoreboard players set SlimeTouch fkbm.options 1

# Makes some slimes capable of fusion between each other with a delay of (N x MobGameplayLatency) seconds
# Default: N = 5 (means 5 x 1 = 5 seconds)
# 0: disabled
# 1+: enabled, N = 1+
execute unless score SlimeFusionCd fkbm.options matches 0.. run scoreboard players set SlimeFusionCd fkbm.options 5

# Allow some slimes to become a powerful ALPHA
# Default: 1
# 0: disabled
# 1: enabled
execute unless score SlimeAlpha fkbm.options matches 0.. run scoreboard players set SlimeAlpha fkbm.options 1

# Slimes ALPHA chance (in %)
# Default: 5
# Range: 0 - 100
execute unless score SlimeAlphaChance fkbm.options matches 0.. run scoreboard players set SlimeAlphaChance fkbm.options 5


## SKELETON

# Enable Skeleton modification
# Default: 1
# 0: disabled
# 1: enabled
execute unless score SkeletonTouch fkbm.options matches 0.. run scoreboard players set SkeletonTouch fkbm.options 1

# Allow some skeletons to break torches
# Default: 1
# 0: disabled
# 1: enabled
execute unless score SkeletonBreakTorch fkbm.options matches 0.. run scoreboard players set SkeletonBreakTorch fkbm.options 1

# Allow some skeletons to fight with swords
# Default: 1
# 0: disabled
# 1: enabled
execute unless score SkeletonSword fkbm.options matches 0.. run scoreboard players set SkeletonSword fkbm.options 1

# Allow some skeletons to use smoke bombs
# Default: 1
# 0: disabled
# 1: enabled
execute unless score SkeletonSmokeBomb fkbm.options matches 0.. run scoreboard players set SkeletonSmokeBomb fkbm.options 1

# Allow some skeletons to use fire bombs
# Default: 1
# 0: disabled
# 1: enabled
execute unless score SkeletonFireBomb fkbm.options matches 0.. run scoreboard players set SkeletonFireBomb fkbm.options 1

# Allow some skeletons to block arrows with a shield
# Default: 1
# 0: disabled
# 1: enabled
execute unless score SkeletonShield fkbm.options matches 0.. run scoreboard players set SkeletonShield fkbm.options 1

# Blocking arrows skill's cooldown
# Default: 1
# Range: 0 - 1
execute unless score SkeletonArrowBlockCd fkbm.options matches 0.. run scoreboard players set SkeletonArrowBlockCd fkbm.options 1

# Allow some skeletons to become a powerful ALPHA
# Default: 1
# 0: disabled
# 1: enabled
execute unless score SkeletonAlpha fkbm.options matches 0.. run scoreboard players set SkeletonAlpha fkbm.options 1

# Skeletons ALPHA chance (in %)
# Default: 5
# Range: 0 - 100
execute unless score SkeletonAlphaChance fkbm.options matches 0.. run scoreboard players set SkeletonAlphaChance fkbm.options 5


## SPIDER

# Enable Spider modification
# Default: 1
# 0: disabled
# 1: enabled
execute unless score SpiderTouch fkbm.options matches 0.. run scoreboard players set SpiderTouch fkbm.options 1

# Allow Spiders to stick to the ceiling
# Default: 1
# 0: disabled
# 1: enabled
execute unless score SpiderCeiling fkbm.options matches 0.. run scoreboard players set SpiderCeiling fkbm.options 1

# Allow some Spiders to spit cobweb at player
# Default: 1
# 0: disabled
# 1: enabled
execute unless score SpiderCobweb fkbm.options matches 0.. run scoreboard players set SpiderCobweb fkbm.options 1

# Allow some Spiders to summon baby cave spiders
# Default: 1
# 0: disabled
# 1: enabled
execute unless score SpiderMommy fkbm.options matches 0.. run scoreboard players set SpiderMommy fkbm.options 1

# Summon baby cave spider skill's cooldown
# Default: 30
# Range: 0 - 99
execute unless score SpiderMommyCd fkbm.options matches 0.. run scoreboard players set SpiderMommyCd fkbm.options 30

# Allow some spiders to become a powerful ALPHA
# Default: 1
# 0: disabled
# 1: enabled
execute unless score SpiderAlpha fkbm.options matches 0.. run scoreboard players set SpiderAlpha fkbm.options 1

# Spiders ALPHA chance (in %)
# Default: 5
# Range: 0 - 100
execute unless score SpiderAlphaChance fkbm.options matches 0.. run scoreboard players set SpiderAlphaChance fkbm.options 5


## STRAY

# Enable stray modification
# Default: 1
# 0: disabled
# 1: enabled
execute unless score StrayTouch fkbm.options matches 0.. run scoreboard players set StrayTouch fkbm.options 1

# Allow some stray to break torches
# Default: 1
# 0: disabled
# 1: enabled
execute unless score StrayBreakTorch fkbm.options matches 0.. run scoreboard players set StrayBreakTorch fkbm.options 1

# Allow some stray to freeze player on touch
# Default: 1
# 0: disabled
# 1: enabled
execute unless score StrayFrozenThorns fkbm.options matches 0.. run scoreboard players set StrayFrozenThorns fkbm.options 1

# Allow some stray to freeze touched nearby water into ice
# Default: 1
# 0: disabled
# 1: enabled
execute unless score StrayFrostWalker fkbm.options matches 0.. run scoreboard players set StrayFrostWalker fkbm.options 1

# Allow some stray to summon an ice prison on close player
# Default: 1
# 0: disabled
# 1: enabled
execute unless score StrayIcePrison fkbm.options matches 0.. run scoreboard players set StrayIcePrison fkbm.options 1

# Ice prison skill's cooldown
# Default: 20
# Range: 0 - 20
execute unless score StrayIcePrisonCd fkbm.options matches 0.. run scoreboard players set StrayIcePrisonCd fkbm.options 20


## VEX

# Enable Vex modification
# Default: 1
# 0: disabled
# 1: enabled
execute unless score VexTouch fkbm.options matches 0.. run scoreboard players set VexTouch fkbm.options 1

# Allow some Vex to use an armored shield giving them some armor
# Default: 1
# 0: disabled
# 1: enabled
execute unless score VexShield fkbm.options matches 0.. run scoreboard players set VexShield fkbm.options 1

# Allow some Vex to dodge most arrows
# Default: 1
# 0: disabled
# 1: enabled
execute unless score VexDodge fkbm.options matches 0.. run scoreboard players set VexDodge fkbm.options 1

# Vex dodge skill's cooldown
# Default: 3
# Range : 0 - 100
execute unless score VexDodgeCd fkbm.options matches 0.. run scoreboard players set VexDodgeCd fkbm.options 3


## VINDICATOR

# Enable Vindicator modification
# Default: 1
# 0: disabled
# 1: enabled
execute unless score VindicatorTouch fkbm.options matches 0.. run scoreboard players set VindicatorTouch fkbm.options 1

# Vindicators spawn chance in Pillager Outposts (in %)
# Default: 50
# 0: disabled
# Range: 0 - 100
execute unless score VindicatorInOutposts fkbm.options matches 0.. run scoreboard players set VindicatorInOutposts fkbm.options 50

# Allow some Vindicators to get dual swords
# Default: 1
# 0: disabled
# 1: enabled
execute unless score VindicatorSword fkbm.options matches 0.. run scoreboard players set VindicatorSword fkbm.options 1

# Allow some vindicators to get a shovel (being dummy and stunning you)
# Default: 1
# 0: disabled
# 1: enabled
execute unless score VindicatorDummy fkbm.options matches 0.. run scoreboard players set VindicatorDummy fkbm.options 1

# Allow some Vindicators to enter Rage mod (increased damage + speed, but get poison)
# Default: 1
# 0: disabled
# 1: enabled
execute unless score VindicatorRage fkbm.options matches 0.. run scoreboard players set VindicatorRage fkbm.options 1


## WITCH

# Enable Witch modification
# Default: 1
# 0: disabled
# 1: enabled
execute unless score WitchTouch fkbm.options matches 0.. run scoreboard players set WitchTouch fkbm.options 1

# Allow some witches to passivly regen health
# Default: 1
# 0: disabled
# 1: enabled
execute unless score WitchRegen fkbm.options matches 0.. run scoreboard players set WitchRegen fkbm.options 1

# Allow some witches to summon minions
# Default: 1
# 0: disabled
# 1: enabled
execute unless score WitchSummon fkbm.options matches 0.. run scoreboard players set WitchSummon fkbm.options 1

# Cooldown of the summon spell
# Default: 1
# 0: disabled
# 1: enabled
execute unless score WitchSummonCd fkbm.options matches 0.. run scoreboard players set WitchSummonCd fkbm.options 40

# Allow some witches to use a time freeze when near death
# Default: 1
# 0: disabled
# 1: enabled
execute unless score WitchZonya fkbm.options matches 0.. run scoreboard players set WitchZonya fkbm.options 1

# Cooldown of the time freeze spell
# Default: 1
# 0: disabled
# 1: enabled
execute unless score WitchZonyaCd fkbm.options matches 0.. run scoreboard players set WitchZonyaCd fkbm.options 60


## WOLF

# Enable Wolf modification
# Default: 1
# 0: disabled
# 1: enabled
execute unless score WolfTouch fkbm.options matches 0.. run scoreboard players set WolfTouch fkbm.options 1

# Makes wild wolfs angry on player close range
# Default: 1
# 0: disabled
# 1: enabled
execute unless score WolfAngry fkbm.options matches 0.. run scoreboard players set WolfAngry fkbm.options 1

# Makes wild wolfs more aggressive during the night
# Default: 1
# 0: disabled
# 1: enabled
execute unless score WolfNightAttack fkbm.options matches 0.. run scoreboard players set WolfNightAttack fkbm.options 1


## ZOMBIE / ZOMBIE_VILLAGER

# Enable Zombie modification
# Default: 1
# 0: disabled
# 1: enabled
execute unless score ZombieTouch fkbm.options matches 0.. run scoreboard players set ZombieTouch fkbm.options 1

# Allow some zombies to break torches
# Default: 1
# 0: disabled
# 1: enabled
execute unless score ZombieBreakTorch fkbm.options matches 0.. run scoreboard players set ZombieBreakTorch fkbm.options 1

# Allow some zombies to break wooden doors instantly (regardless of the difficulty)
# Default: 1
# 0: disabled
# 1: enabled
execute unless score ZombieBreakDoor fkbm.options matches 0.. run scoreboard players set ZombieBreakDoor fkbm.options 1

# Allow some zombies to break wooden fences instantly (regardless of the difficulty)
# Default: 1
# 0: disabled
# 1: enabled
execute unless score ZombieBreakFence fkbm.options matches 0.. run scoreboard players set ZombieBreakFence fkbm.options 1

# Allow some zombies to place dirt when a player is higher
# Default: 1
# 0: disabled
# 1: enabled
execute unless score ZombieCanBuild fkbm.options matches 0.. run scoreboard players set ZombieCanBuild fkbm.options 1

# Allow some zombies to dig into soft materials (sand, gravel, dirt...)
# Default: 1
# 0: disabled
# 1: enabled
execute unless score ZombieCanDig fkbm.options matches 0.. run scoreboard players set ZombieCanDig fkbm.options 1

# Time required (seconds) to dig into soft materials (sand, gravel, dirt...). Stacks if multiple zombie diggers.
# Default: 3
# 0: instant
# Range: 1 - 99
execute unless score ZombieDigTime fkbm.options matches 0.. run scoreboard players set ZombieDigTime fkbm.options 3
