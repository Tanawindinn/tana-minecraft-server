scoreboard objectives add fkbm.options dummy {"text":"Better Vanilla Mobs Options","color":"#80a0b4"}
scoreboard objectives add fkbm.compat dummy {"text":"Better Vanilla Mobs Compatibility","color":"#80a0b4"}
scoreboard objectives add fkbm.dim dummy {"text":"fkbm.dim","color":"#80a0b4"}
scoreboard objectives add fkbm.cd dummy {"text":"fkbm.cd","color":"#80a0b4"}
scoreboard objectives add fkbm.var dummy {"text":"fkbm.var","color":"#80a0b4"}

team add fkbm.spider
team modify fkbm.spider nametagVisibility never

function fkbm:compatibility/checks
function fkbm:properties
function fkbm:adv/revoke_all
function fkbm:schedules/list

schedule function fkbm:compatibility/checks 5t

tellraw @a ["",{"text":"[BetterVanillaMobs] ","bold":true,"color":"gold","hoverEvent":{"action":"show_text","value":[{"text":"Developed with love by "},{"text":"FunkyToc","color":"dark_purple","bold":true}]}},{"text":"Enabled ! "},{"text":"More infos on "},{"text":"funkytoc.fr","color":"dark_purple","clickEvent":{"action":"open_url","value":"https://funkytoc.fr/en/home/"}}]
execute if score McVersion fktool matches ..11602 run tellraw @a ["",{"text":"[BetterVanillaMobs] ","bold":true,"color":"gold","hoverEvent":{"action":"show_text","value":[{"text":"Developed with love by "},{"text":"FunkyToc","color":"dark_purple","bold":true}]}},{"text":"Version 1.16 or inferior detected !","color":"red"}]
execute if score McVersion fktool matches ..11602 run tellraw @a ["",{"text":"[BetterVanillaMobs] ","bold":true,"color":"gold","hoverEvent":{"action":"show_text","value":[{"text":"Developed with love by "},{"text":"FunkyToc","color":"dark_purple","bold":true}]}},{"text":"This datapack needs 1.17+","color":"red"}]
execute if score McVersion fktool matches 11700.. run tellraw @a ["",{"text":"[BetterVanillaMobs] ","bold":true,"color":"gold","hoverEvent":{"action":"show_text","value":[{"text":"Developed with love by "},{"text":"FunkyToc","color":"dark_purple","bold":true}]}},{"text":"Modify Options "},{"text":"[click here]","bold":true,"color":"aqua","clickEvent":{"action":"suggest_command","value":"/function fkbm:options/get"}}]
execute if score McVersion fktool matches 11700.. run tellraw @a ["",{"text":"[BetterVanillaMobs] ","bold":true,"color":"gold","hoverEvent":{"action":"show_text","value":[{"text":"Developed with love by "},{"text":"FunkyToc","color":"dark_purple","bold":true}]}},{"text":"You're playing the FREE version, get the full version "},{"text":"[becoming a Patreon]","bold":true,"color":"aqua","clickEvent":{"action":"open_url","value":"https://www.patreon.com/funkytoc"}}]

function fkbm:compatibility/infos
