tag @e remove fkbm.touched

scoreboard players reset * fkbm.options
scoreboard players reset * fkbm.compat
scoreboard players reset * fkbm.dim
scoreboard players reset * fkbm.cd
scoreboard players reset * fkbm.var

scoreboard objectives remove fkbm.options
scoreboard objectives remove fkbm.compat
scoreboard objectives remove fkbm.dim
scoreboard objectives remove fkbm.cd
scoreboard objectives remove fkbm.var

function fktool:uninstall

datapack disable "file/BetterVanillaMobs.zip"
datapack disable "file/BetterVanillaMobs"
datapack disable "file/BetterVanillaMobs_FREE.zip"
datapack disable "file/BetterVanillaMobs_FREE"

tellraw @s ["",{"text":"[BetterVanillaMobs] ","bold":true,"color":"gold"},{"text":"Uninstalled","color":"gray"}]
