# easy
execute if score Difficulty fkbm.options matches 1 if predicate fktool:rng/25 run tag @s add fkbm.spider.cobweb
execute if score Difficulty fkbm.options matches 1 if predicate fktool:rng/5 run tag @s add fkbm.spider.mommy
execute if score Difficulty fkbm.options matches 1 run data merge entity @s {Health:20f,Attributes:[{Name:generic.max_health,Base:20},{Name:generic.attack_damage,Base:2},{Name:generic.movement_speed,Base:0.32}]}

# normal
execute if score Difficulty fkbm.options matches 2 if predicate fktool:rng/50 run tag @s add fkbm.spider.cobweb
execute if score Difficulty fkbm.options matches 2 if predicate fktool:rng/10 run tag @s add fkbm.spider.mommy
execute if score Difficulty fkbm.options matches 2 run data merge entity @s {Health:25f,Attributes:[{Name:generic.max_health,Base:25},{Name:generic.attack_damage,Base:4},{Name:generic.movement_speed,Base:0.34}]}

# hard
execute if score Difficulty fkbm.options matches 3 if predicate fktool:rng/75 run tag @s add fkbm.spider.cobweb
execute if score Difficulty fkbm.options matches 3 if predicate fktool:rng/15 run tag @s add fkbm.spider.mommy
execute if score Difficulty fkbm.options matches 3 run data merge entity @s {Health:30f,Attributes:[{Name:generic.max_health,Base:30},{Name:generic.attack_damage,Base:6},{Name:generic.movement_speed,Base:0.36}]}

# shared
execute if score SpiderCeiling fkbm.options matches 1 run team join fkbm.spider @s
scoreboard players set @s[tag=fkbm.spider.mommy] fkbm.cd 0

# alpha
execute if score SpiderAlpha fkbm.options matches 1 run function fktool:rng/get
execute if score SpiderAlpha fkbm.options matches 1 if score SpiderAlphaChance fkbm.options > Random fktool run tag @s add fkbm.spider.alpha
execute as @s[tag=fkbm.spider.alpha] run function fkbm:systems/mobs/touch/alpha/spider

tag @s add fkbm.touched