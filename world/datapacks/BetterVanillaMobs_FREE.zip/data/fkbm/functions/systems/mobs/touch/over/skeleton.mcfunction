# easy
execute if score Difficulty fkbm.options matches 1 if predicate fktool:rng/50 run tag @s add fkbm.skeleton.torch
execute if score Difficulty fkbm.options matches 1 if predicate fktool:rng/25 run tag @s add fkbm.skeleton.sword
execute if score Difficulty fkbm.options matches 1 if predicate fktool:rng/10 run tag @s add fkbm.skeleton.shield
execute if score Difficulty fkbm.options matches 1 if predicate fktool:rng/20 run tag @s add fkbm.skeleton.smokebomb
execute if score Difficulty fkbm.options matches 1 run data merge entity @s {Health:20f,HandItems:[{id:"minecraft:bow",Count:1b},{}],Attributes:[{Name:generic.max_health,Base:20},{Name:generic.follow_range,Base:32},{Name:generic.knockback_resistance,Base:0.1},{Name:generic.movement_speed,Base:0.23}]}

# normal
execute if score Difficulty fkbm.options matches 2 if predicate fktool:rng/75 run tag @s add fkbm.skeleton.torch
execute if score Difficulty fkbm.options matches 2 if predicate fktool:rng/50 run tag @s add fkbm.skeleton.sword
execute if score Difficulty fkbm.options matches 2 if predicate fktool:rng/20 run tag @s add fkbm.skeleton.shield
execute if score Difficulty fkbm.options matches 2 if predicate fktool:rng/40 run tag @s add fkbm.skeleton.smokebomb
execute if score Difficulty fkbm.options matches 2 run data merge entity @s {Health:30f,HandItems:[{id:"minecraft:bow",Count:1b},{}],Attributes:[{Name:generic.max_health,Base:30},{Name:generic.follow_range,Base:32},{Name:generic.knockback_resistance,Base:0.2},{Name:generic.movement_speed,Base:0.26}]}

# hard
execute if score Difficulty fkbm.options matches 3 if predicate fktool:rng/95 run tag @s add fkbm.skeleton.torch
execute if score Difficulty fkbm.options matches 3 if predicate fktool:rng/75 run tag @s add fkbm.skeleton.sword
execute if score Difficulty fkbm.options matches 3 if predicate fktool:rng/30 run tag @s add fkbm.skeleton.shield
execute if score Difficulty fkbm.options matches 3 if predicate fktool:rng/60 run tag @s add fkbm.skeleton.smokebomb
execute if score Difficulty fkbm.options matches 3 run data merge entity @s {Health:40f,HandItems:[{id:"minecraft:bow",Count:1b},{}],Attributes:[{Name:generic.max_health,Base:40},{Name:generic.follow_range,Base:32},{Name:generic.knockback_resistance,Base:0.3},{Name:generic.movement_speed,Base:0.28}]}

# alpha
execute if score SkeletonAlpha fkbm.options matches 1 run function fktool:rng/get
execute if score SkeletonAlpha fkbm.options matches 1 if score SkeletonAlphaChance fkbm.options > Random fktool run tag @s add fkbm.skeleton.alpha
execute as @s[tag=fkbm.skeleton.alpha] run function fkbm:systems/mobs/touch/alpha/skeleton

# shared
execute if predicate fkbm:mobs/head_air run data merge entity @s {ArmorItems:[{},{},{},{id:"minecraft:stone_button",Count:1b}],ArmorDropChances:[0.085F,0.085F,0.085F,0.000F],Fire:-1s}
execute if entity @s[tag=fkbm.skeleton.shield] run item replace entity @s weapon.offhand with minecraft:shield{display:{Name:'{"text":"Buckler","italic":false}'}}
scoreboard players set @s[tag=fkbm.skeleton.shield] fkbm.cd 0

tag @s add fkbm.touched