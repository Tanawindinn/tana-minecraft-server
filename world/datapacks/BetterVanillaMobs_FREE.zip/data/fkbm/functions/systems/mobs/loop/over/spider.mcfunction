# ceiling
execute if score SpiderCeiling fkbm.options matches 1 run function fkbm:systems/mobs/events/spider_ceiling

# spit
execute if score SpiderCobweb fkbm.options matches 1 if predicate fktool:time/period/the_night as @s[tag=!fkbm.spider.spited] if entity @p[distance=4..8,gamemode=!creative,gamemode=!spectator] run function fkbm:systems/mobs/events/spider_cobweb
execute unless entity @p[distance=..10,gamemode=!creative,gamemode=!spectator] run tag @s remove fkbm.spider.spited

# mommy
execute if score SpiderMommy fkbm.options matches 1 if entity @s[tag=fkbm.spider.mommy,tag=!fkbm.spider.summoned,scores={fkbm.cd=..0}] if entity @p[distance=..16,gamemode=!creative,gamemode=!spectator] run function fkbm:systems/mobs/events/spider_summon_baby
execute if score SpiderMommy fkbm.options matches 1 if entity @s[tag=fkbm.spider.summoned] at @s unless entity @e[type=minecraft:cave_spider,tag=fkbm.spider.baby,distance=..12] run tag @s remove fkbm.spider.summoned
scoreboard players operation @s[tag=fkbm.spider.mommy,scores={fkbm.cd=1..}] fkbm.cd -= MobGameplayLatency fkbm.options

# alpha
execute if score SpiderAlpha fkbm.options matches 1 as @s[tag=fkbm.spider.alpha] if entity @p[distance=..6,gamemode=!creative,gamemode=!spectator] run fill ~ ~ ~ ~ ~ ~ minecraft:cobweb replace #fkbm:spider_cocoon

tag @s add fkbm.looped