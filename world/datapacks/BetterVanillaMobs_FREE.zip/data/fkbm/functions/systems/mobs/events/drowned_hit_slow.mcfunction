advancement revoke @s only fkbm:mobs/drowned_hit_slow

execute as @e[type=minecraft:drowned,tag=fkbm.drowned.hitslow,distance=..12] at @s run playsound minecraft:entity.drowned.death_water hostile @a[distance=..16] ~ ~ ~ 1 .7 .2
execute as @e[type=minecraft:drowned,tag=fkbm.drowned.hitslow,distance=..12] at @s run playsound minecraft:entity.ghast.hurt hostile @a[distance=..16] ~ ~ ~ .2 .5 .2

execute if score Difficulty fkbm.options matches 1 run effect give @s minecraft:slowness 1 0 true
execute if score Difficulty fkbm.options matches 2 run effect give @s minecraft:slowness 1 1 true
execute if score Difficulty fkbm.options matches 3 run effect give @s minecraft:slowness 1 2 true

execute if score Difficulty fkbm.options matches 1 run effect give @e[type=minecraft:drowned,tag=fkbm.drowned.hitslow,distance=..12,predicate=fktool:entity/in_water_feet] minecraft:speed 5 1 true
execute if score Difficulty fkbm.options matches 2 run effect give @e[type=minecraft:drowned,tag=fkbm.drowned.hitslow,distance=..12,predicate=fktool:entity/in_water_feet] minecraft:speed 5 3 true
execute if score Difficulty fkbm.options matches 3 run effect give @e[type=minecraft:drowned,tag=fkbm.drowned.hitslow,distance=..12,predicate=fktool:entity/in_water_feet] minecraft:speed 5 5 true