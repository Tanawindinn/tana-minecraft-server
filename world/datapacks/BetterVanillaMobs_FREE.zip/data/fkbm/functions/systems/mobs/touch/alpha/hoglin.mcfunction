# rename
execute if score RenameAlphaMobs fkbm.options matches 1 run data modify entity @s CustomName set value '{"text":"\\u2620 Alpha Hoglin \\u2620","color":"red"}'

# spe
attribute @s minecraft:generic.movement_speed modifier add 26061990-2023-02-10-002 fkbm.hoglin.alpha_speed 0.1 multiply_base
attribute @s minecraft:generic.armor modifier add 26061990-2023-02-10-002 fkbm.hoglin.alpha_armor 6 add
attribute @s minecraft:generic.attack_damage modifier add 26061990-2023-02-10-002 fkbm.hoglin.alpha_dmg 2 add
attribute @s minecraft:generic.knockback_resistance modifier add 26061990-2023-02-10-002 fkbm.hoglin.alpha_knockback_res 1 add
attribute @s minecraft:generic.attack_knockback modifier add 26061990-2023-02-10-002 fkbm.hoglin.alpha_knockback_atk 0.5 add
effect give @s minecraft:regeneration 999999 0 true
