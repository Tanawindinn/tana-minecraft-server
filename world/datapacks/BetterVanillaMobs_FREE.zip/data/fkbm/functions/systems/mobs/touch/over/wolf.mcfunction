# easy
execute if score Difficulty fkbm.options matches 1 if predicate fktool:rng/50 run tag @s add fkbm.wolf.angry
execute if score Difficulty fkbm.options matches 1 unless predicate fkbm:mobs/is_baby run data merge entity @s {Health:12f,CanPickUpLoot:1b,Attributes:[{Name:generic.max_health,Base:12},{Name:generic.follow_range,Base:64},{Name:generic.movement_speed,Base:0.40}]}
execute if score Difficulty fkbm.options matches 1 if predicate fkbm:mobs/is_baby run data merge entity @s {Health:6f,CanPickUpLoot:1b,Attributes:[{Name:generic.max_health,Base:6},{Name:generic.follow_range,Base:64},{Name:generic.movement_speed,Base:0.30}]}

# normal
execute if score Difficulty fkbm.options matches 2 if predicate fktool:rng/75 run tag @s add fkbm.wolf.angry
execute if score Difficulty fkbm.options matches 2 unless predicate fkbm:mobs/is_baby run data merge entity @s {Health:16f,CanPickUpLoot:1b,Attributes:[{Name:generic.max_health,Base:16},{Name:generic.follow_range,Base:64},{Name:generic.movement_speed,Base:0.40}]}
execute if score Difficulty fkbm.options matches 2 if predicate fkbm:mobs/is_baby run data merge entity @s {Health:8f,CanPickUpLoot:1b,Attributes:[{Name:generic.max_health,Base:8},{Name:generic.follow_range,Base:64},{Name:generic.movement_speed,Base:0.30}]}

# hard
execute if score Difficulty fkbm.options matches 3 if predicate fktool:rng/95 run tag @s add fkbm.wolf.angry
execute if score Difficulty fkbm.options matches 3 unless predicate fkbm:mobs/is_baby run data merge entity @s {Health:20f,CanPickUpLoot:1b,Attributes:[{Name:generic.max_health,Base:20},{Name:generic.follow_range,Base:64},{Name:generic.movement_speed,Base:0.40}]}
execute if score Difficulty fkbm.options matches 3 if predicate fkbm:mobs/is_baby run data merge entity @s {Health:10f,CanPickUpLoot:1b,Attributes:[{Name:generic.max_health,Base:10},{Name:generic.follow_range,Base:64},{Name:generic.movement_speed,Base:0.30}]}

# shared
tag @s[tag=fkbm.baby] remove fkbm.baby
execute if predicate fkbm:mobs/is_baby run tag @s add fkbm.baby

tag @s add fkbm.touched