# easy
execute if score Difficulty fkbm.options matches 1 if predicate fktool:rng/20 run tag @s add fkbm.vindicator.sword
execute if score Difficulty fkbm.options matches 1 if predicate fktool:rng/40 run tag @s add fkbm.vindicator.dummy
execute if score Difficulty fkbm.options matches 1 if predicate fktool:rng/20 run tag @s add fkbm.vindicator.rage
execute if score Difficulty fkbm.options matches 1 run data merge entity @s {Health:24f,Attributes:[{Name:generic.max_health,Base:24},{Name:generic.armor,Base:4},{Name:generic.knockback_resistance,Base:0.3}]}

# normal
execute if score Difficulty fkbm.options matches 2 if predicate fktool:rng/30 run tag @s add fkbm.vindicator.sword
execute if score Difficulty fkbm.options matches 2 if predicate fktool:rng/30 run tag @s add fkbm.vindicator.dummy
execute if score Difficulty fkbm.options matches 2 if predicate fktool:rng/40 run tag @s add fkbm.vindicator.rage
execute if score Difficulty fkbm.options matches 2 run data merge entity @s {Health:30f,Attributes:[{Name:generic.max_health,Base:30},{Name:generic.armor,Base:7},{Name:generic.knockback_resistance,Base:0.4}]}

# hard
execute if score Difficulty fkbm.options matches 3 if predicate fktool:rng/40 run tag @s add fkbm.vindicator.sword
execute if score Difficulty fkbm.options matches 3 if predicate fktool:rng/20 run tag @s add fkbm.vindicator.dummy
execute if score Difficulty fkbm.options matches 3 if predicate fktool:rng/60 run tag @s add fkbm.vindicator.rage
execute if score Difficulty fkbm.options matches 3 run data merge entity @s {Health:36f,Attributes:[{Name:generic.max_health,Base:36},{Name:generic.armor,Base:10},{Name:generic.knockback_resistance,Base:0.5}]}

# shared
execute if entity @s[tag=fkbm.vindicator.sword] run data modify entity @s HandItems set value [{id:"minecraft:iron_sword",Count:1b},{id:"minecraft:iron_sword",Count:1b}]
execute if entity @s[tag=fkbm.vindicator.dummy] run data modify entity @s HandItems set value [{id:"minecraft:iron_shovel",Count:1b},{id:"minecraft:dirt",Count:1b}]

tag @s add fkbm.touched