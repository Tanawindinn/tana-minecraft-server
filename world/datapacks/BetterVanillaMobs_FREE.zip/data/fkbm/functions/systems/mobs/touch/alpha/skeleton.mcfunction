# rename
execute if score RenameAlphaMobs fkbm.options matches 1 if entity @s[tag=fkbm.skeleton.alpha] run data modify entity @s CustomName set value '{"text":"\\u2620 Alpha Skeleton \\u2620","color":"red"}'

# spe
attribute @s minecraft:generic.movement_speed modifier add 26061990-2023-02-13-002 fkbm.skeleton.alpha_speed 0.1 multiply_base
attribute @s minecraft:generic.armor modifier add 26061990-2023-02-13-002 fkbm.skeleton.alpha_armor 10 add
attribute @s minecraft:generic.attack_damage modifier add 26061990-2023-02-13-002 fkbm.skeleton.alpha_dmg 2 add
effect give @s minecraft:fire_resistance 999999 0 true
