# gunfreeze
# see advancement

# vortex
execute if score EndermanVortex fkbm.options matches 1 if entity @s[tag=fkbm.enderman.vortex,nbt=!{AngerTime:0}] if entity @p[distance=..6,gamemode=!creative,gamemode=!spectator] run scoreboard players operation @s fkbm.var += MobGameplayLatency fkbm.options
execute if score EndermanVortex fkbm.options matches 1 if entity @s[tag=fkbm.enderman.vortex,scores={fkbm.var=30..}] run function fkbm:systems/mobs/events/enderman_vortex
scoreboard players operation @s[tag=fkbm.enderman.vortex,scores={fkbm.var=1..}] fkbm.var -= MobGameplayLatency fkbm.options

# lookbreak
execute if score EndermanLookbreak fkbm.options matches 1 if entity @s[tag=fkbm.enderman.lookbreak,scores={fkbm.cd=..0},nbt=!{AngerTime:0}] if entity @p[distance=..4,gamemode=!creative,gamemode=!spectator] anchored eyes facing entity @p eyes rotated ~ 0 positioned ^ ^ ^.6 unless block ~ ~ ~ air if block ~ ~-1 ~ air if block ~ ~ ~ #fkbm:enderman_lookbreak if block ~ ~-2 ~ #fkbm:enderman_lookbreak run function fkbm:systems/mobs/events/enderman_lookbreak
scoreboard players operation @s[tag=fkbm.enderman.lookbreak,scores={fkbm.cd=1..}] fkbm.cd -= MobGameplayLatency fkbm.options

tag @s add fkbm.looped