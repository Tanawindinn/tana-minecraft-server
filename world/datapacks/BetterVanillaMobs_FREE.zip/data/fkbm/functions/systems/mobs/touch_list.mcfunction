# compatibility: do not modify special mobs
function fkbm:compatibility/pre_secure

# modify mobs
execute if score OverTouch fkbm.options matches 1 at @a[scores={fkbm.dim=0}] run function fkbm:systems/mobs/touch/touch_over
execute if score NetherTouch fkbm.options matches 1 at @a[scores={fkbm.dim=-1}] run function fkbm:systems/mobs/touch/touch_nether
execute if score EndTouch fkbm.options matches 1 at @a[scores={fkbm.dim=1}] run function fkbm:systems/mobs/touch/touch_end

# compatibility: secure my mobs
function fkbm:compatibility/post_secure