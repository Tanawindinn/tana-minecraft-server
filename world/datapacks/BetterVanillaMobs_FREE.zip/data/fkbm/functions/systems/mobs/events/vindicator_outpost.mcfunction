# in Pillager Outposts, spawn some vindicator instead
function fktool:rng/get
execute if score Random fktool <= VindicatorInOutposts fkbm.options at @s run function fkbm:systems/mobs/events/pillager_to_vindicator