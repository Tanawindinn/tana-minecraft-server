# break torch
execute if score StrayBreakTorch fkbm.options matches 1 if entity @s[tag=fkbm.stray.torch] if entity @p[distance=..16] run function fkbm:systems/mobs/events/break_torches

# frost walker
execute if score StrayFrostWalker fkbm.options matches 1 if entity @s[tag=fkbm.stray.frostwalker] if block ~ ~ ~ minecraft:water if block ~ ~1 ~ #fktool:airs run function fkbm:systems/mobs/events/frost_walker

# frozen thorns
# see advancement

# ice prison
execute if score StrayIcePrison fkbm.options matches 1 if entity @s[tag=fkbm.stray.iceprison,tag=!fkbm.stray.iceprisoned,scores={fkbm.cd=..0}] if entity @p[distance=..4,gamemode=!creative,gamemode=!spectator] run function fkbm:systems/mobs/events/stray_ice_prison
execute if score StrayIcePrison fkbm.options matches 1 if entity @s[tag=fkbm.stray.iceprisoned] at @s unless entity @p[distance=..10,gamemode=!creative,gamemode=!spectator] run tag @s remove fkbm.stray.iceprisoned
scoreboard players operation @s[tag=fkbm.stray.iceprison,scores={fkbm.cd=1..}] fkbm.cd -= MobGameplayLatency fkbm.options

tag @s add fkbm.looped