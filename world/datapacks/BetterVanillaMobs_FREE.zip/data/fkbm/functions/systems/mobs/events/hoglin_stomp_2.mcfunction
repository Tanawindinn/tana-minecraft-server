effect give @a[gamemode=!creative,gamemode=!spectator,distance=..6] minecraft:slowness 2 2 true
execute as @a[gamemode=!creative,gamemode=!spectator,distance=..6] at @s run tp @s ~ ~-.6 ~ ~ ~30

playsound minecraft:entity.hoglin.step hostile @a[distance=..32] ~ ~ ~ 5 .8
playsound minecraft:entity.generic.explode hostile @a[distance=..32] ~ ~ ~ 1 .5
particle minecraft:dust_color_transition .8 .8 .6 2 1 1 .9 ~ ~.2 ~ 2 .1 2 0 50
execute if predicate fktool:location/in_over run particle minecraft:block dirt ~ ~.2 ~ 2 .1 2 0 200
execute if predicate fktool:location/in_nether run particle minecraft:block netherrack ~ ~.2 ~ 2 .1 2 0 200

tag @s remove fkbm.hoglin.stomp.step1