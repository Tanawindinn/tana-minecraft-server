fill ~-1 ~0 ~-2 ~1 ~-1 ~2 minecraft:ice replace minecraft:water
fill ~-2 ~0 ~-1 ~2 ~-1 ~1 minecraft:ice replace minecraft:water
fill ~-1 ~-2 ~-1 ~1 ~-2 ~1 minecraft:ice replace minecraft:water

particle minecraft:dust_color_transition .5 .5 1 2 1 1 1 ~ ~-1 ~ 2 .5 2 0 50
playsound minecraft:block.amethyst_block.fall hostile @a[distance=..16] ~ ~-1 ~ 1 .5 .5