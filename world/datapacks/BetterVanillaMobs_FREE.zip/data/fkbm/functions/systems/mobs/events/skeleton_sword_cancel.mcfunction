# equip bow
item replace entity @s weapon.mainhand with minecraft:bow
data merge entity @s {HandDropChances:[0.085F,0.085F]}

tag @s remove fkbm.skeleton.sworded