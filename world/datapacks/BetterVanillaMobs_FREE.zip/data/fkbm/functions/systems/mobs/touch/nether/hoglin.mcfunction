# easy
execute if score Difficulty fkbm.options matches 1 if predicate fktool:rng/10 run tag @s add fkbm.hoglin.hotblood
execute if score Difficulty fkbm.options matches 1 if predicate fktool:rng/25 unless predicate fkbm:mobs/is_baby run tag @s add fkbm.hoglin.stomp
execute if score Difficulty fkbm.options matches 1 unless predicate fkbm:mobs/is_baby run data merge entity @s {Health:50f,Attributes:[{Name:generic.max_health,Base:50},{Name:generic.movement_speed,Base:0.35},{Name:generic.armor,Base:6}]}
execute if score Difficulty fkbm.options matches 1 if predicate fkbm:mobs/is_baby run data merge entity @s {Attributes:[{Name:generic.movement_speed,Base:0.35},{Name:generic.armor,Base:6}]}

# normal
execute if score Difficulty fkbm.options matches 2 if predicate fktool:rng/20 run tag @s add fkbm.hoglin.hotblood
execute if score Difficulty fkbm.options matches 2 if predicate fktool:rng/50 unless predicate fkbm:mobs/is_baby run tag @s add fkbm.hoglin.stomp
execute if score Difficulty fkbm.options matches 2 unless predicate fkbm:mobs/is_baby run data merge entity @s {Health:60f,Attributes:[{Name:generic.max_health,Base:60},{Name:generic.movement_speed,Base:0.38},{Name:generic.armor,Base:8}]}
execute if score Difficulty fkbm.options matches 2 if predicate fkbm:mobs/is_baby run data merge entity @s {Attributes:[{Name:generic.movement_speed,Base:0.35},{Name:generic.armor,Base:6}]}

# hard
execute if score Difficulty fkbm.options matches 3 if predicate fktool:rng/30 run tag @s add fkbm.hoglin.hotblood
execute if score Difficulty fkbm.options matches 3 if predicate fktool:rng/75 unless predicate fkbm:mobs/is_baby run tag @s add fkbm.hoglin.stomp
execute if score Difficulty fkbm.options matches 3 unless predicate fkbm:mobs/is_baby run data merge entity @s {Health:70f,Attributes:[{Name:generic.max_health,Base:70},{Name:generic.movement_speed,Base:0.42},{Name:generic.armor,Base:10}]}
execute if score Difficulty fkbm.options matches 3 if predicate fkbm:mobs/is_baby run data merge entity @s {Attributes:[{Name:generic.movement_speed,Base:0.35},{Name:generic.armor,Base:6}]}

# alpha
execute if score HoglinAlpha fkbm.options matches 1 unless predicate fkbm:mobs/is_baby run function fktool:rng/get
execute if score HoglinAlpha fkbm.options matches 1 unless predicate fkbm:mobs/is_baby if score HoglinAlphaChance fkbm.options > Random fktool run tag @s add fkbm.hoglin.alpha
execute as @s[tag=fkbm.hoglin.alpha] run function fkbm:systems/mobs/touch/alpha/hoglin

# shared
execute if entity @s[tag=fkbm.hoglin.hotblood] run data merge entity @s {IsImmuneToZombification:1b}
scoreboard players set @s[tag=fkbm.hoglin.stomp] fkbm.cd 0

tag @s add fkbm.touched