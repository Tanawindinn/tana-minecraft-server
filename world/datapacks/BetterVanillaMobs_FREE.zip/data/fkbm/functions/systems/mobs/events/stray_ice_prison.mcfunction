execute at @p[distance=..4,gamemode=!creative,gamemode=!spectator] run fill ~ ~ ~ ~ ~1 ~ minecraft:structure_void replace #fktool:airs
execute at @p[distance=..4,gamemode=!creative,gamemode=!spectator] run fill ~ ~-1 ~ ~ ~2 ~ minecraft:ice replace #fktool:airs
execute at @p[distance=..4,gamemode=!creative,gamemode=!spectator] run fill ~1 ~ ~ ~-1 ~ ~ minecraft:ice replace #fktool:airs
execute at @p[distance=..4,gamemode=!creative,gamemode=!spectator] run fill ~ ~ ~1 ~ ~ ~-1 minecraft:ice replace #fktool:airs
execute at @p[distance=..4,gamemode=!creative,gamemode=!spectator] run fill ~ ~ ~ ~ ~1 ~ minecraft:air replace minecraft:structure_void
execute at @p[distance=..4,gamemode=!creative,gamemode=!spectator] run fill ~ ~ ~ ~ ~ ~ minecraft:powder_snow destroy

execute at @p[distance=..4,gamemode=!creative,gamemode=!spectator] run particle minecraft:snowflake ~ ~1 ~ .3 1 .3 .1 10
execute at @p[distance=..4,gamemode=!creative,gamemode=!spectator] run particle minecraft:dust_color_transition .5 .5 1 2 1 1 1 ~ ~1 ~ .5 .5 .5 0 20
execute at @p[distance=..4,gamemode=!creative,gamemode=!spectator] run playsound minecraft:block.glass.break hostile @a[distance=..16] ^ ^ ^2 3 .5 .5

tag @s add fkbm.stray.iceprisoned
scoreboard players operation @s fkbm.cd = StrayIcePrisonCd fkbm.options