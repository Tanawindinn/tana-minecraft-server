# firework rocket
execute if score PillagerFireworkRocket fkbm.options matches 1 if entity @s[tag=fkbm.pillager.firework,scores={fkbm.cd=..0}] run function fkbm:systems/mobs/events/pillager_firework
scoreboard players operation @s[tag=fkbm.pillager.firework,scores={fkbm.cd=1..}] fkbm.cd -= MobGameplayLatency fkbm.options

tag @s add fkbm.looped