# break torch
execute if score SkeletonBreakTorch fkbm.options matches 1 if entity @s[tag=fkbm.skeleton.torch] if entity @p[distance=..16] run function fkbm:systems/mobs/events/break_torches

# get sword
execute if score SkeletonSword fkbm.options matches 1 if entity @s[tag=fkbm.skeleton.sword,tag=!fkbm.skeleton.sworded] if entity @p[distance=..6,gamemode=!creative,gamemode=!spectator] run function fkbm:systems/mobs/events/skeleton_sword
execute if score SkeletonSword fkbm.options matches 1 if entity @s[tag=fkbm.skeleton.sword,tag=fkbm.skeleton.sworded] unless entity @p[distance=..10,gamemode=!creative,gamemode=!spectator] run function fkbm:systems/mobs/events/skeleton_sword_cancel

# arrow block
execute if score SkeletonShield fkbm.options matches 1 if entity @s[tag=fkbm.skeleton.shield,scores={fkbm.cd=..0}] run function fkbm:systems/mobs/events/skeleton_arrowblock_loop
scoreboard players operation @s[tag=fkbm.skeleton.shield,scores={fkbm.cd=1..}] fkbm.cd -= MobGameplayLatency fkbm.options

# smoke bomb
execute if score SkeletonSmokeBomb fkbm.options matches 1 if entity @s[tag=fkbm.skeleton.smokebomb,tag=!fkbm.skeleton.smoked] if entity @p[distance=..5,gamemode=!creative,gamemode=!spectator] run function fkbm:systems/mobs/events/skeleton_smokebomb
execute if score SkeletonSmokeBomb fkbm.options matches 1 if entity @s[tag=fkbm.skeleton.smokebomb,tag=fkbm.skeleton.smoked] at @s unless entity @p[distance=..10,gamemode=!creative,gamemode=!spectator] run tag @s remove fkbm.skeleton.smoked

# alpha
execute if score SkeletonAlpha fkbm.options matches 1 as @s[tag=fkbm.skeleton.alpha] if entity @p[distance=..12] run particle minecraft:white_ash ~ ~.8 ~ .2 .4 .2 0 10

tag @s add fkbm.looped