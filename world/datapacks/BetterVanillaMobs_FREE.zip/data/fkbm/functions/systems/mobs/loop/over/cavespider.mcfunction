# ceiling
execute if score CavespiderCeiling fkbm.options matches 1 run function fkbm:systems/mobs/events/spider_ceiling

# nausea bites
# see advancement

tag @s add fkbm.looped