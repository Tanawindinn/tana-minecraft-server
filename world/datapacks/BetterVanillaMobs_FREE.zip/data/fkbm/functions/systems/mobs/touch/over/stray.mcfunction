# easy
execute if score Difficulty fkbm.options matches 1 if predicate fktool:rng/50 run tag @s add fkbm.stray.torch
execute if score Difficulty fkbm.options matches 1 if predicate fktool:rng/40 run tag @s add fkbm.stray.frozenthorns
execute if score Difficulty fkbm.options matches 1 if predicate fktool:rng/40 run tag @s add fkbm.stray.frostwalker
execute if score Difficulty fkbm.options matches 1 if predicate fktool:rng/20 run tag @s add fkbm.stray.iceprison
execute if score Difficulty fkbm.options matches 1 run data merge entity @s {Health:20f,HandItems:[{id:"minecraft:bow",Count:1b},{}],Attributes:[{Name:generic.max_health,Base:20},{Name:generic.follow_range,Base:32},{Name:generic.attack_knockback,Base:0.1},{Name:generic.movement_speed,Base:0.23}]}

# normal
execute if score Difficulty fkbm.options matches 2 if predicate fktool:rng/75 run tag @s add fkbm.stray.torch
execute if score Difficulty fkbm.options matches 2 if predicate fktool:rng/60 run tag @s add fkbm.stray.frozenthorns
execute if score Difficulty fkbm.options matches 2 if predicate fktool:rng/60 run tag @s add fkbm.stray.frostwalker
execute if score Difficulty fkbm.options matches 2 if predicate fktool:rng/35 run tag @s add fkbm.stray.iceprison
execute if score Difficulty fkbm.options matches 2 run data merge entity @s {Health:30f,HandItems:[{id:"minecraft:bow",Count:1b},{}],Attributes:[{Name:generic.max_health,Base:30},{Name:generic.follow_range,Base:32},{Name:generic.attack_knockback,Base:0.2},{Name:generic.movement_speed,Base:0.26}]}

# hard
execute if score Difficulty fkbm.options matches 3 if predicate fktool:rng/95 run tag @s add fkbm.stray.torch
execute if score Difficulty fkbm.options matches 3 if predicate fktool:rng/80 run tag @s add fkbm.stray.frozenthorns
execute if score Difficulty fkbm.options matches 3 if predicate fktool:rng/80 run tag @s add fkbm.stray.frostwalker
execute if score Difficulty fkbm.options matches 3 if predicate fktool:rng/50 run tag @s add fkbm.stray.iceprison
execute if score Difficulty fkbm.options matches 3 run data merge entity @s {Health:40f,HandItems:[{id:"minecraft:bow",Count:1b},{}],Attributes:[{Name:generic.max_health,Base:40},{Name:generic.follow_range,Base:32},{Name:generic.attack_knockback,Base:0.3},{Name:generic.movement_speed,Base:0.28}]}

# shared
execute if predicate fkbm:mobs/head_air run data merge entity @s {ArmorItems:[{},{},{},{id:"minecraft:stone_button",Count:1b}],ArmorDropChances:[0.085F,0.085F,0.085F,0.000F],Fire:-1s}
scoreboard players set @s[tag=fkbm.stray.iceprison] fkbm.cd 0

tag @s add fkbm.touched