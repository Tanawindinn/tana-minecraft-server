# break torch
execute if score ZombieBreakTorch fkbm.options matches 1 if entity @s[tag=fkbm.zombie.torch] if entity @p[distance=..24] run function fkbm:systems/mobs/events/break_torches

# break door
execute if score ZombieBreakDoor fkbm.options matches 1 if entity @s[tag=fkbm.zombie.door] if entity @p[distance=..16,gamemode=!creative,gamemode=!spectator] if predicate fktool:rng/25 if block ^ ^.2 ^.4 #fkbm:zombie_breakdoor run fill ^ ^.2 ^.4 ^ ^.2 ^.4 minecraft:air destroy

# break fence
execute if score ZombieBreakFence fkbm.options matches 1 if entity @s[tag=fkbm.zombie.fence] if entity @p[distance=..16,gamemode=!creative,gamemode=!spectator] if predicate fktool:rng/25 if block ^ ^.2 ^.9 #fkbm:zombie_breakfence run fill ^ ^.2 ^.9 ^ ^.2 ^.9 minecraft:air destroy

# build
execute if score ZombieCanBuild fkbm.options matches 1 if entity @s[tag=fkbm.zombie.build,nbt={OnGround:1b}] if entity @p[distance=..12,gamemode=!creative,gamemode=!spectator] positioned ~-1 ~3 ~-1 if entity @p[dy=8,dx=2,dz=2] at @s if block ~ ~ ~ minecraft:air if block ~ ~2.5 ~ minecraft:air run fill ~ ~ ~ ~ ~ ~ minecraft:dirt destroy
execute if score ZombieCanBuild fkbm.options matches 1 if entity @s[tag=fkbm.zombie.build,nbt={OnGround:1b}] if entity @p[distance=..12,gamemode=!creative,gamemode=!spectator] positioned ~-1 ~3 ~-1 if entity @p[dy=8,dx=2,dz=2] at @s if block ~ ~ ~ minecraft:dirt if block ~ ~2.5 ~ minecraft:air run tp @s ~ ~1 ~

# dig
execute if score ZombieCanDig fkbm.options matches 1 if entity @s[tag=fkbm.zombie.dig] if entity @p[distance=..12,gamemode=!creative,gamemode=!spectator] positioned ~-2 ~-1 ~-2 if entity @p[dy=-12,dx=4,dz=4] at @s positioned ~ ~-.4 ~ if block ~ ~ ~ #fkbm:zombie_dig align xyz positioned ~ ~.5 ~ run function fkbm:systems/mobs/events/zombie_dig
execute if score ZombieCanDig fkbm.options matches 1 if entity @s[tag=fkbm.zombie.dig] if entity @p[distance=..8,gamemode=!creative,gamemode=!spectator] facing entity @p feet positioned ^ ^ ^1 positioned ~ ~1.2 ~ if block ~ ~ ~ #fkbm:zombie_dig align xyz positioned ~ ~.5 ~ run function fkbm:systems/mobs/events/zombie_dig
execute if score ZombieCanDig fkbm.options matches 1 if entity @s[tag=fkbm.zombie.dig] if entity @p[distance=..8,gamemode=!creative,gamemode=!spectator] facing entity @p feet positioned ^ ^ ^1 positioned ~ ~0.2 ~ if block ~ ~ ~ #fkbm:zombie_dig align xyz positioned ~ ~.5 ~ run function fkbm:systems/mobs/events/zombie_dig

tag @s add fkbm.looped