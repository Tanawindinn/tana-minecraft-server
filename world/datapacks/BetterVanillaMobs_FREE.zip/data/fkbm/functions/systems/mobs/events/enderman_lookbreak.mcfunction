fill ~ ~ ~ ~ ~-2 ~ air destroy
particle minecraft:dragon_breath ~ ~-1 ~ .1 .8 .1 0 5

# cd
execute if score Difficulty fkbm.options matches 1 run scoreboard players set @s fkbm.cd 5
execute if score Difficulty fkbm.options matches 2 run scoreboard players set @s fkbm.cd 3
execute if score Difficulty fkbm.options matches 3 run scoreboard players set @s fkbm.cd 1