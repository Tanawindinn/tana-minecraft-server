# get size
execute store result score @s fkbm.var run data get entity @s Size 1

# alpha size
execute if score SlimeAlpha fkbm.options matches 1 if score @s fkbm.var matches 3 run function fktool:rng/get
execute if score SlimeAlpha fkbm.options matches 1 if score @s fkbm.var matches 3 if score SlimeAlphaChance fkbm.options > Random fktool run tag @s add fkbm.slime.alpha
execute if entity @s[tag=fkbm.slime.alpha] run function fkbm:systems/mobs/touch/alpha/slime
execute if entity @s[tag=fkbm.slime.alpha] run scoreboard players set @s fkbm.var 6

# easy
execute if score Difficulty fkbm.options matches 1 if predicate fktool:rng/50 run tag @s add fkbm.slime.fusion
execute if score Difficulty fkbm.options matches 1 if score @s fkbm.var matches 0 run data merge entity @s {Health:4f,Attributes:[{Name:generic.max_health,Base:4},{Name:generic.knockback_resistance,Base:0.01}]}
execute if score Difficulty fkbm.options matches 1 if score @s fkbm.var matches 1..2 run data merge entity @s {Health:8f,Attributes:[{Name:generic.max_health,Base:8},{Name:generic.knockback_resistance,Base:0.20}]}
execute if score Difficulty fkbm.options matches 1 if score @s fkbm.var matches 3..5 run data merge entity @s {Health:16f,Attributes:[{Name:generic.max_health,Base:16},{Name:generic.knockback_resistance,Base:0.50}]}
execute if score Difficulty fkbm.options matches 1 if score @s fkbm.var matches 6.. run data merge entity @s {Health:32f,Attributes:[{Name:generic.max_health,Base:32},{Name:generic.knockback_resistance,Base:1.00}]}

# normal
execute if score Difficulty fkbm.options matches 2 if predicate fktool:rng/75 run tag @s add fkbm.slime.fusion
execute if score Difficulty fkbm.options matches 2 if score @s fkbm.var matches 0 run data merge entity @s {Health:6f,Attributes:[{Name:generic.max_health,Base:6},{Name:generic.knockback_resistance,Base:0.01}]}
execute if score Difficulty fkbm.options matches 2 if score @s fkbm.var matches 1..2 run data merge entity @s {Health:12f,Attributes:[{Name:generic.max_health,Base:12},{Name:generic.knockback_resistance,Base:0.20}]}
execute if score Difficulty fkbm.options matches 2 if score @s fkbm.var matches 3..5 run data merge entity @s {Health:24f,Attributes:[{Name:generic.max_health,Base:24},{Name:generic.knockback_resistance,Base:0.50}]}
execute if score Difficulty fkbm.options matches 2 if score @s fkbm.var matches 6.. run data merge entity @s {Health:48f,Attributes:[{Name:generic.max_health,Base:48},{Name:generic.knockback_resistance,Base:1.00}]}

# hard
execute if score Difficulty fkbm.options matches 3 if predicate fktool:rng/99 run tag @s add fkbm.slime.fusion
execute if score Difficulty fkbm.options matches 3 if score @s fkbm.var matches 0 run data merge entity @s {Health:8f,Attributes:[{Name:generic.max_health,Base:8},{Name:generic.knockback_resistance,Base:0.01}]}
execute if score Difficulty fkbm.options matches 3 if score @s fkbm.var matches 1..2 run data merge entity @s {Health:16f,Attributes:[{Name:generic.max_health,Base:16},{Name:generic.knockback_resistance,Base:0.20}]}
execute if score Difficulty fkbm.options matches 3 if score @s fkbm.var matches 3..5 run data merge entity @s {Health:32f,Attributes:[{Name:generic.max_health,Base:32},{Name:generic.knockback_resistance,Base:0.50}]}
execute if score Difficulty fkbm.options matches 3 if score @s fkbm.var matches 6.. run data merge entity @s {Health:64f,Attributes:[{Name:generic.max_health,Base:64},{Name:generic.knockback_resistance,Base:1.00}]}

# shared


tag @s add fkbm.touched