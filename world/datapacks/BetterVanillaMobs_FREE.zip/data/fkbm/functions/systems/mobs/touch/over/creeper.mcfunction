# easy
execute if score Difficulty fkbm.options matches 1 if predicate fktool:rng/25 run tag @s add fkbm.creeper.bait
execute if score Difficulty fkbm.options matches 1 if predicate fktool:rng/10 run tag @s add fkbm.creeper.unstable
execute if score Difficulty fkbm.options matches 1 run data merge entity @s {Health:20f,Fuse:30s,Attributes:[{Name:generic.max_health,Base:20},{Name:generic.movement_speed,Base:0.28}]}

# normal
execute if score Difficulty fkbm.options matches 2 if predicate fktool:rng/50 run tag @s add fkbm.creeper.bait
execute if score Difficulty fkbm.options matches 2 if predicate fktool:rng/20 run tag @s add fkbm.creeper.unstable
execute if score Difficulty fkbm.options matches 2 run data merge entity @s {Health:25f,Fuse:30s,Attributes:[{Name:generic.max_health,Base:25},{Name:generic.movement_speed,Base:0.30}]}

# hard
execute if score Difficulty fkbm.options matches 3 if predicate fktool:rng/75 run tag @s add fkbm.creeper.bait
execute if score Difficulty fkbm.options matches 3 if predicate fktool:rng/30 run tag @s add fkbm.creeper.unstable
execute if score Difficulty fkbm.options matches 3 run data merge entity @s {Health:30f,Fuse:30s,Attributes:[{Name:generic.max_health,Base:30},{Name:generic.movement_speed,Base:0.32}]}

# shared
execute if score CreeperRandomExplosionRadius fkbm.options matches 1 run function fkbm:systems/mobs/touch/skill/creeper_random_radius
execute if score CreeperRandomFuse fkbm.options matches 1 run function fkbm:systems/mobs/touch/skill/creeper_random_fuse

# alpha
execute if score CreeperAlpha fkbm.options matches 1 run function fktool:rng/get
execute if score CreeperAlpha fkbm.options matches 1 if score CreeperAlphaChance fkbm.options > Random fktool run tag @s add fkbm.creeper.alpha
execute as @s[tag=fkbm.creeper.alpha] run function fkbm:systems/mobs/touch/alpha/creeper


tag @s add fkbm.touched