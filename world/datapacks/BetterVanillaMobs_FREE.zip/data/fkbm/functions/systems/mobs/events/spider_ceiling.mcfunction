execute if block ~ ~-1 ~ #fktool:airs unless block ~ ~1 ~ #fktool:airs unless entity @s[nbt={Passengers:[{id:"minecraft:minecraft:skeleton"}]}] run data merge entity @s {CustomName:'{"text":"Grumm"}'}

execute if score RenameAlphaMobs fkbm.options matches 0..1 if block ~ ~1 ~ #fktool:airs run data merge entity @s[tag=!fkbm.spider.alpha] {CustomName:'{"text":""}'}
execute if score RenameAlphaMobs fkbm.options matches 1..1 if block ~ ~1 ~ #fktool:airs run data merge entity @s[tag=fkbm.spider.alpha] {CustomName:'{"text":"\\u2620 Alpha Spider \\u2620","color":"red"}'}