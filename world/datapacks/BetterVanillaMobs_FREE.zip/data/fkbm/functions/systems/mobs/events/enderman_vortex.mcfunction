tag @a[gamemode=!creative,gamemode=!spectator,distance=..8,sort=nearest,limit=3] add fkbm.enderman.vortexed
tag @a[tag=fkbm.enderman.vortexed] add fkbm.enderman.vortexed.effect
spreadplayers ~ ~ 5 30 false @a[tag=fkbm.enderman.vortexed]
schedule function fkbm:systems/mobs/events/enderman_vortex_anim 2t
tag @a[tag=fkbm.enderman.vortexed] remove fkbm.enderman.vortexed

scoreboard players set @s fkbm.var 0