summon minecraft:vindicator ~ ~ ~
tp @s ~ ~-200 ~