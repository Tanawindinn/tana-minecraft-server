# slow on lands
execute if score Difficulty fkbm.options matches 1 unless predicate fktool:entity/in_water_feet run effect give @s minecraft:slowness 5 2 true
execute if score Difficulty fkbm.options matches 2 unless predicate fktool:entity/in_water_feet run effect give @s minecraft:slowness 5 1 true
execute if score Difficulty fkbm.options matches 3 unless predicate fktool:entity/in_water_feet run effect give @s minecraft:slowness 5 1 true

tag @s add fkbm.looped