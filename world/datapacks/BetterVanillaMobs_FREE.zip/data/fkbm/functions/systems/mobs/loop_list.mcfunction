# get dimension
scoreboard players set @a[predicate=fktool:location/in_over] fkbm.dim 0
scoreboard players set @a[predicate=fktool:location/in_nether] fkbm.dim -1
scoreboard players set @a[predicate=fktool:location/in_end] fkbm.dim 1

# gameplay
execute if score OverTouch fkbm.options matches 1 at @a[scores={fkbm.dim=0}] run function fkbm:systems/mobs/loop/loop_over
execute if score NetherTouch fkbm.options matches 1 at @a[scores={fkbm.dim=-1}] run function fkbm:systems/mobs/loop/loop_nether
execute if score EndTouch fkbm.options matches 1 at @a[scores={fkbm.dim=1}] run function fkbm:systems/mobs/loop/loop_end

tag @e[tag=fkbm.looped] remove fkbm.looped