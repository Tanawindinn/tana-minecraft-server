particle minecraft:warped_spore ~ ~1 ~ .2 .4 .2 0 10
particle minecraft:composter ~ ~1 ~ .3 .5 .3 0 5

scoreboard players operation #tmp fkbm.cd = WitchZonyaCd fkbm.options
scoreboard players operation #tmp fkbm.cd -= #3 fktool
execute if score @s fkbm.cd <= #tmp fkbm.cd run data modify entity @s Invulnerable set value 0b
execute if score @s fkbm.cd <= #tmp fkbm.cd run tag @s remove fkbm.with.zonya.effect