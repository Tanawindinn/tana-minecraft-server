advancement revoke @s only fkbm:mobs/cavespider_hit_nausea

execute as @e[type=minecraft:cave_spider,tag=fkbm.cavespider.nausea,limit=1,distance=..5] at @s run playsound minecraft:entity.spider.hurt hostile @a[distance=..16] ~ ~ ~ 1 1.4 .2
execute facing entity @e[type=minecraft:cave_spider,tag=fkbm.cavespider.nausea,limit=1,distance=..5] eyes rotated ~ 0 positioned ^ ^1 ^.6 run particle minecraft:block slime_block ~ ~ ~ .1 .1 .1 0 10

execute if score Difficulty fkbm.options matches 1 run effect give @s minecraft:slowness 3 0 true
execute if score Difficulty fkbm.options matches 2 run effect give @s minecraft:slowness 4 1 true
execute if score Difficulty fkbm.options matches 3 run effect give @s minecraft:slowness 5 2 true

execute if score Difficulty fkbm.options matches 1 run effect give @s minecraft:nausea 5 0 true
execute if score Difficulty fkbm.options matches 2 run effect give @s minecraft:nausea 6 0 true
execute if score Difficulty fkbm.options matches 3 run effect give @s minecraft:nausea 7 0 true