# dodge
execute if score VexDodge fkbm.options matches 1 if entity @s[tag=fkbm.vex.dodge] run function fkbm:systems/mobs/events/vex_dodge_loop
scoreboard players operation @s[tag=fkbm.vex.dodge,scores={fkbm.cd=1..}] fkbm.cd -= MobGameplayLatency fkbm.options

tag @s add fkbm.looped