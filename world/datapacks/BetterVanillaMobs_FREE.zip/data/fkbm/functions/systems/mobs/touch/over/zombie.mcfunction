# easy
execute if score Difficulty fkbm.options matches 1 if predicate fktool:rng/50 run tag @s add fkbm.zombie.torch
execute if score Difficulty fkbm.options matches 1 if predicate fktool:rng/50 run tag @s add fkbm.zombie.door
execute if score Difficulty fkbm.options matches 1 if predicate fktool:rng/25 run tag @s add fkbm.zombie.fence
execute if score Difficulty fkbm.options matches 1 if predicate fktool:rng/15 run tag @s add fkbm.zombie.dig
execute if score Difficulty fkbm.options matches 1 if predicate fktool:rng/10 run tag @s add fkbm.zombie.build
execute if score Difficulty fkbm.options matches 1 unless predicate fkbm:mobs/is_baby run data merge entity @s {Health:20f,CanPickUpLoot:1b,CanBreakDoors:1b,Attributes:[{Name:generic.max_health,Base:20},{Name:generic.attack_damage,Base:3},{Name:generic.follow_range,Base:32},{Name:generic.knockback_resistance,Base:0.2},{Name:generic.movement_speed,Base:0.26}]}
execute if score Difficulty fkbm.options matches 1 if predicate fkbm:mobs/is_baby run data merge entity @s {Health:8f,CanPickUpLoot:1b,Attributes:[{Name:generic.max_health,Base:8},{Name:generic.follow_range,Base:32},{Name:generic.knockback_resistance,Base:0.2},{Name:generic.movement_speed,Base:0.16}]}

# normal
execute if score Difficulty fkbm.options matches 2 if predicate fktool:rng/75 run tag @s add fkbm.zombie.torch
execute if score Difficulty fkbm.options matches 2 if predicate fktool:rng/75 run tag @s add fkbm.zombie.door
execute if score Difficulty fkbm.options matches 2 if predicate fktool:rng/50 run tag @s add fkbm.zombie.fence
execute if score Difficulty fkbm.options matches 2 if predicate fktool:rng/40 run tag @s add fkbm.zombie.dig
execute if score Difficulty fkbm.options matches 2 if predicate fktool:rng/20 run tag @s add fkbm.zombie.build
execute if score Difficulty fkbm.options matches 2 unless predicate fkbm:mobs/is_baby run data merge entity @s {Health:30f,CanPickUpLoot:1b,CanBreakDoors:1b,Attributes:[{Name:generic.max_health,Base:30},{Name:generic.attack_damage,Base:4},{Name:generic.follow_range,Base:48},{Name:generic.knockback_resistance,Base:0.4},{Name:generic.movement_speed,Base:0.31}]}
execute if score Difficulty fkbm.options matches 2 if predicate fkbm:mobs/is_baby run data merge entity @s {Health:10f,CanPickUpLoot:1b,Attributes:[{Name:generic.max_health,Base:10},{Name:generic.follow_range,Base:48},{Name:generic.knockback_resistance,Base:0.4},{Name:generic.movement_speed,Base:0.20}]}

# hard
execute if score Difficulty fkbm.options matches 3 if predicate fktool:rng/95 run tag @s add fkbm.zombie.torch
execute if score Difficulty fkbm.options matches 3 if predicate fktool:rng/95 run tag @s add fkbm.zombie.door
execute if score Difficulty fkbm.options matches 3 if predicate fktool:rng/75 run tag @s add fkbm.zombie.fence
execute if score Difficulty fkbm.options matches 3 if predicate fktool:rng/50 run tag @s add fkbm.zombie.dig
execute if score Difficulty fkbm.options matches 3 if predicate fktool:rng/25 run tag @s add fkbm.zombie.build
execute if score Difficulty fkbm.options matches 3 unless predicate fkbm:mobs/is_baby run data merge entity @s {Health:40f,CanPickUpLoot:1b,CanBreakDoors:1b,Attributes:[{Name:generic.max_health,Base:40},{Name:generic.attack_damage,Base:6},{Name:generic.follow_range,Base:64},{Name:generic.knockback_resistance,Base:0.6},{Name:generic.movement_speed,Base:0.36}]}
execute if score Difficulty fkbm.options matches 3 if predicate fkbm:mobs/is_baby run data merge entity @s {Health:12f,CanPickUpLoot:1b,Attributes:[{Name:generic.max_health,Base:12},{Name:generic.follow_range,Base:64},{Name:generic.knockback_resistance,Base:0.6},{Name:generic.movement_speed,Base:0.24}]}

# shared
execute if predicate fkbm:mobs/head_air run data merge entity @s {ArmorItems:[{},{},{},{id:"minecraft:stone_button",Count:1b}],ArmorDropChances:[0.085F,0.085F,0.085F,0.000F],Fire:-1s}

tag @s add fkbm.touched