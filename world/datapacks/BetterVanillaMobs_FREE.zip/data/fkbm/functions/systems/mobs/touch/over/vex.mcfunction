# easy
execute if score Difficulty fkbm.options matches 1 if predicate fktool:rng/25 run tag @s add fkbm.vex.dodge
execute if score Difficulty fkbm.options matches 1 if predicate fktool:rng/30 run tag @s add fkbm.vex.shield
execute if score Difficulty fkbm.options matches 1 if predicate fktool:rng/30 run tag @s[tag=!fkbm.vex.shield] add fkbm.vex.swordleft
execute if score Difficulty fkbm.options matches 1 if predicate fktool:rng/20 run tag @s add fkbm.vex.axe
execute if score Difficulty fkbm.options matches 1 run data merge entity @s {Health:14f,Attributes:[{Name:generic.max_health,Base:14}]}

# normal
execute if score Difficulty fkbm.options matches 2 if predicate fktool:rng/50 run tag @s add fkbm.vex.dodge
execute if score Difficulty fkbm.options matches 2 if predicate fktool:rng/30 run tag @s add fkbm.vex.shield
execute if score Difficulty fkbm.options matches 2 if predicate fktool:rng/30 run tag @s[tag=!fkbm.vex.shield] add fkbm.vex.swordleft
execute if score Difficulty fkbm.options matches 2 if predicate fktool:rng/30 run tag @s add fkbm.vex.axe
execute if score Difficulty fkbm.options matches 2 run data merge entity @s {Health:18f,Attributes:[{Name:generic.max_health,Base:18}]}

# hard
execute if score Difficulty fkbm.options matches 3 if predicate fktool:rng/75 run tag @s add fkbm.vex.dodge
execute if score Difficulty fkbm.options matches 3 if predicate fktool:rng/30 run tag @s add fkbm.vex.shield
execute if score Difficulty fkbm.options matches 3 if predicate fktool:rng/30 run tag @s[tag=!fkbm.vex.shield] add fkbm.vex.swordleft
execute if score Difficulty fkbm.options matches 3 if predicate fktool:rng/40 run tag @s add fkbm.vex.axe
execute if score Difficulty fkbm.options matches 3 run data merge entity @s {Health:22f,Attributes:[{Name:generic.max_health,Base:22}]}

# shared
execute if entity @s[tag=fkbm.vex.shield] if score VexShield fkbm.options matches 1 run attribute @s minecraft:generic.armor modifier add 26061990-2023-02-10-001 fkbm.vex.shield_armor 10 add
execute if entity @s[tag=fkbm.vex.shield] run item replace entity @s weapon.offhand with minecraft:shield{display:{Name:'{"text":"Buckler","italic":false}'}}
execute if entity @s[tag=fkbm.vex.swordleft] run item replace entity @s weapon.offhand with minecraft:iron_sword{display:{Name:'{"text":"Iron Dagger","italic":false}'}}
execute if entity @s[tag=fkbm.vex.axe] run item replace entity @s weapon.mainhand with minecraft:iron_axe{display:{Name:'{"text":"Iron Hatchet","italic":false}'}}
scoreboard players set @s[tag=fkbm.vex.dodge] fkbm.cd 0

tag @s add fkbm.touched