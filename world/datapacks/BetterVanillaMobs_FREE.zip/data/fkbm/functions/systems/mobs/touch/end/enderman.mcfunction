# easy
execute if score Difficulty fkbm.options matches 1 if predicate fktool:rng/50 run tag @s add fkbm.enderman.lookfreeze
execute if score Difficulty fkbm.options matches 1 if predicate fktool:rng/50 run tag @s add fkbm.enderman.lookbreak
execute if score Difficulty fkbm.options matches 1 if predicate fktool:rng/25 run tag @s add fkbm.enderman.vortex
execute if score Difficulty fkbm.options matches 1 run data merge entity @s {Health:40f,Attributes:[{Name:generic.max_health,Base:40},{Name:generic.attack_knockback,Base:0.1},{Name:generic.movement_speed,Base:0.30}]}

# normal
execute if score Difficulty fkbm.options matches 2 if predicate fktool:rng/75 run tag @s add fkbm.enderman.lookfreeze
execute if score Difficulty fkbm.options matches 2 if predicate fktool:rng/75 run tag @s add fkbm.enderman.lookbreak
execute if score Difficulty fkbm.options matches 2 if predicate fktool:rng/50 run tag @s add fkbm.enderman.vortex
execute if score Difficulty fkbm.options matches 2 run data merge entity @s {Health:50f,Attributes:[{Name:generic.max_health,Base:50},{Name:generic.attack_knockback,Base:0.2},{Name:generic.movement_speed,Base:0.35}]}

# hard
execute if score Difficulty fkbm.options matches 3 if predicate fktool:rng/95 run tag @s add fkbm.enderman.lookfreeze
execute if score Difficulty fkbm.options matches 3 if predicate fktool:rng/95 run tag @s add fkbm.enderman.lookbreak
execute if score Difficulty fkbm.options matches 3 if predicate fktool:rng/75 run tag @s add fkbm.enderman.vortex
execute if score Difficulty fkbm.options matches 3 run data merge entity @s {Health:60f,Attributes:[{Name:generic.max_health,Base:60},{Name:generic.attack_knockback,Base:0.3},{Name:generic.movement_speed,Base:0.40}]}

#shared
scoreboard players set @s[tag=fkbm.enderman.vortex] fkbm.var 0
scoreboard players set @s[tag=fkbm.enderman.lookbreak] fkbm.cd 0

tag @s add fkbm.touched