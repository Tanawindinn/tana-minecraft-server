# easy
execute if score Difficulty fkbm.options matches 1 if predicate fktool:rng/50 run tag @s add fkbm.husk.torch
execute if score Difficulty fkbm.options matches 1 if predicate fktool:rng/30 run tag @s add fkbm.husk.door
execute if score Difficulty fkbm.options matches 1 if predicate fktool:rng/25 run tag @s add fkbm.husk.fence
execute if score Difficulty fkbm.options matches 1 if predicate fktool:rng/50 run tag @s add fkbm.husk.hitslow
execute if score Difficulty fkbm.options matches 1 if predicate fktool:rng/30 run tag @s add fkbm.husk.regen
execute if score Difficulty fkbm.options matches 1 unless predicate fkbm:mobs/is_baby run data merge entity @s {Health:50f,CanPickUpLoot:1b,CanBreakDoors:1b,Attributes:[{Name:generic.max_health,Base:50},{Name:generic.attack_damage,Base:3},{Name:generic.follow_range,Base:64},{Name:generic.knockback_resistance,Base:0.3},{Name:generic.movement_speed,Base:0.16}]}
execute if score Difficulty fkbm.options matches 1 if predicate fkbm:mobs/is_baby run data merge entity @s {Health:20f,CanPickUpLoot:1b,Attributes:[{Name:generic.max_health,Base:20},{Name:generic.follow_range,Base:64},{Name:generic.knockback_resistance,Base:0.3},{Name:generic.movement_speed,Base:0.16}]}

# normal
execute if score Difficulty fkbm.options matches 2 if predicate fktool:rng/75 run tag @s add fkbm.husk.torch
execute if score Difficulty fkbm.options matches 2 if predicate fktool:rng/50 run tag @s add fkbm.husk.door
execute if score Difficulty fkbm.options matches 2 if predicate fktool:rng/50 run tag @s add fkbm.husk.fence
execute if score Difficulty fkbm.options matches 2 if predicate fktool:rng/75 run tag @s add fkbm.husk.hitslow
execute if score Difficulty fkbm.options matches 2 if predicate fktool:rng/60 run tag @s add fkbm.husk.regen
execute if score Difficulty fkbm.options matches 2 unless predicate fkbm:mobs/is_baby run data merge entity @s {Health:60f,CanPickUpLoot:1b,CanBreakDoors:1b,Attributes:[{Name:generic.max_health,Base:60},{Name:generic.attack_damage,Base:4},{Name:generic.follow_range,Base:64},{Name:generic.knockback_resistance,Base:0.6},{Name:generic.movement_speed,Base:0.18}]}
execute if score Difficulty fkbm.options matches 2 if predicate fkbm:mobs/is_baby run data merge entity @s {Health:25f,CanPickUpLoot:1b,Attributes:[{Name:generic.max_health,Base:25},{Name:generic.follow_range,Base:64},{Name:generic.knockback_resistance,Base:0.6},{Name:generic.movement_speed,Base:0.18}]}

# hard
execute if score Difficulty fkbm.options matches 3 if predicate fktool:rng/95 run tag @s add fkbm.husk.torch
execute if score Difficulty fkbm.options matches 3 if predicate fktool:rng/70 run tag @s add fkbm.husk.door
execute if score Difficulty fkbm.options matches 3 if predicate fktool:rng/75 run tag @s add fkbm.husk.fence
execute if score Difficulty fkbm.options matches 3 if predicate fktool:rng/95 run tag @s add fkbm.husk.hitslow
execute if score Difficulty fkbm.options matches 3 if predicate fktool:rng/90 run tag @s add fkbm.husk.regen
execute if score Difficulty fkbm.options matches 3 unless predicate fkbm:mobs/is_baby run data merge entity @s {Health:70f,CanPickUpLoot:1b,CanBreakDoors:1b,Attributes:[{Name:generic.max_health,Base:70},{Name:generic.attack_damage,Base:6},{Name:generic.follow_range,Base:64},{Name:generic.knockback_resistance,Base:0.9},{Name:generic.movement_speed,Base:0.20}]}
execute if score Difficulty fkbm.options matches 3 if predicate fkbm:mobs/is_baby run data merge entity @s {Health:30f,CanPickUpLoot:1b,Attributes:[{Name:generic.max_health,Base:30},{Name:generic.follow_range,Base:64},{Name:generic.knockback_resistance,Base:0.9},{Name:generic.movement_speed,Base:0.20}]}

# shared
execute if predicate fkbm:mobs/head_air run data merge entity @s {ArmorItems:[{},{},{},{id:"minecraft:stone_button",Count:1b}],ArmorDropChances:[0.085F,0.085F,0.085F,0.000F],Fire:-1s}

tag @s add fkbm.touched