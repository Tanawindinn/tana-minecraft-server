# easy
execute if score Difficulty fkbm.options matches 1 if predicate fktool:rng/30 run tag @s add fkbm.evoker.groupregen
execute if score Difficulty fkbm.options matches 1 if predicate fktool:rng/20 run tag @s add fkbm.evoker.root
execute if score Difficulty fkbm.options matches 1 run data merge entity @s {Health:30f,Attributes:[{Name:generic.max_health,Base:30},{Name:generic.armor,Base:4},{Name:generic.movement_speed,Base:0.50}]}

# normal
execute if score Difficulty fkbm.options matches 2 if predicate fktool:rng/50 run tag @s add fkbm.evoker.groupregen
execute if score Difficulty fkbm.options matches 2 if predicate fktool:rng/30 run tag @s add fkbm.evoker.root
execute if score Difficulty fkbm.options matches 2 run data merge entity @s {Health:36f,Attributes:[{Name:generic.max_health,Base:36},{Name:generic.armor,Base:7},{Name:generic.movement_speed,Base:0.53}]}

# hard
execute if score Difficulty fkbm.options matches 3 if predicate fktool:rng/70 run tag @s add fkbm.evoker.groupregen
execute if score Difficulty fkbm.options matches 3 if predicate fktool:rng/50 run tag @s add fkbm.evoker.root
execute if score Difficulty fkbm.options matches 3 run data merge entity @s {Health:42f,Attributes:[{Name:generic.max_health,Base:42},{Name:generic.armor,Base:10},{Name:generic.movement_speed,Base:0.56}]}

# shared
scoreboard players set @s[tag=fkbm.evoker.groupregen] fkbm.cd 0
scoreboard players set @s[tag=fkbm.evoker.root] fkbm.var 0

tag @s add fkbm.touched