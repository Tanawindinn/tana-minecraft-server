# equip sword
execute if score Difficulty fkbm.options matches 1 run item replace entity @s weapon.mainhand with minecraft:stone_sword{display:{Name:'{"text":"Stone Dagger","italic":false}'}}
execute if score Difficulty fkbm.options matches 2 run item replace entity @s weapon.mainhand with minecraft:iron_sword{display:{Name:'{"text":"Iron Dagger","italic":false}'}}
execute if score Difficulty fkbm.options matches 3 run item replace entity @s weapon.mainhand with minecraft:netherite_sword{display:{Name:'{"text":"Netherite Dagger","italic":false}'}}
execute if score Difficulty fkbm.options matches 3 run data merge entity @s {HandDropChances:[0.000F,0.085F]}

tag @s add fkbm.skeleton.sworded