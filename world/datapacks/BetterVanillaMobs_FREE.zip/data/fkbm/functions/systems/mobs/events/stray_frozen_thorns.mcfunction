advancement revoke @s only fkbm:mobs/stray_frozen_thorns

execute if score Difficulty fkbm.options matches 1 run effect give @s minecraft:slowness 1 0 true
execute if score Difficulty fkbm.options matches 2 run effect give @s minecraft:slowness 1 2 true
execute if score Difficulty fkbm.options matches 3 run effect give @s minecraft:slowness 1 4 true

particle minecraft:snowflake ~ ~1 ~ .3 .5 .3 .1 30
particle minecraft:block ice ~ ~1 ~ .3 .5 .3 .1 10
playsound minecraft:block.glass.break hostile @a[distance=..16] ^ ^ ^2 1 .5 .5