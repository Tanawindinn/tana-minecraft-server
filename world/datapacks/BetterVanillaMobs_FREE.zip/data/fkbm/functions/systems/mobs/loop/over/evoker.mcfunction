# root
execute if score EvokerRoot fkbm.options matches 1 if entity @s[tag=fkbm.evoker.root,scores={fkbm.var=..0}] if entity @p[distance=..10,gamemode=!creative,gamemode=!spectator] run function fkbm:systems/mobs/events/evoker_root
scoreboard players operation @s[tag=fkbm.evoker.root,scores={fkbm.var=1..}] fkbm.var -= MobGameplayLatency fkbm.options

# group regen
execute if score EvokerGroupHeal fkbm.options matches 1 if entity @s[tag=fkbm.evoker.groupregen] store result score #tmp fkbm.cd run data get entity @s Health
execute if score EvokerGroupHeal fkbm.options matches 1 if entity @s[tag=fkbm.evoker.groupregen] if score #tmp fkbm.cd matches ..21 if entity @s[scores={fkbm.cd=..0}] run function fkbm:systems/mobs/events/evoker_group_regen
scoreboard players operation @s[tag=fkbm.evoker.groupregen,scores={fkbm.cd=1..}] fkbm.cd -= MobGameplayLatency fkbm.options

tag @s add fkbm.looped