# easy
execute if score Difficulty fkbm.options matches 1 if predicate fktool:rng/25 run tag @s add fkbm.illusioner.enchantedbow
execute if score Difficulty fkbm.options matches 1 if predicate fktool:rng/20 run tag @s add fkbm.illusioner.heal
execute if score Difficulty fkbm.options matches 1 if predicate fktool:rng/10 run tag @s add fkbm.illusioner.cdbuff
execute if score Difficulty fkbm.options matches 1 run data merge entity @s {Health:30f,SpellTicks:10,Attributes:[{Name:generic.max_health,Base:30},{Name:generic.armor,Base:2}],HandItems:[{id:"minecraft:bow",Count:1b}]}

# normal
execute if score Difficulty fkbm.options matches 2 if predicate fktool:rng/50 run tag @s add fkbm.illusioner.enchantedbow
execute if score Difficulty fkbm.options matches 2 if predicate fktool:rng/40 run tag @s add fkbm.illusioner.heal
execute if score Difficulty fkbm.options matches 2 if predicate fktool:rng/20 run tag @s add fkbm.illusioner.cdbuff
execute if score Difficulty fkbm.options matches 2 run data merge entity @s {Health:40f,SpellTicks:10,Attributes:[{Name:generic.max_health,Base:40},{Name:generic.armor,Base:4}],HandItems:[{id:"minecraft:bow",Count:1b}]}

# hard
execute if score Difficulty fkbm.options matches 3 if predicate fktool:rng/75 run tag @s add fkbm.illusioner.enchantedbow
execute if score Difficulty fkbm.options matches 3 if predicate fktool:rng/60 run tag @s add fkbm.illusioner.heal
execute if score Difficulty fkbm.options matches 3 if predicate fktool:rng/30 run tag @s add fkbm.illusioner.cdbuff
execute if score Difficulty fkbm.options matches 3 run data merge entity @s {Health:50f,SpellTicks:10,Attributes:[{Name:generic.max_health,Base:50},{Name:generic.armor,Base:6}],HandItems:[{id:"minecraft:bow",Count:1b}]}

# shared
execute if score IllusionerEnchantedBow fkbm.options matches 1 if score Difficulty fkbm.options matches 1 if entity @s[tag=fkbm.illusioner.enchantedbow] run data merge entity @s {HandItems:[{id:"minecraft:bow",Count:1b,tag:{Enchantments:[{id:"minecraft:power",lvl:1s},{id:"minecraft:punch",lvl:1s}]}}]}
execute if score IllusionerEnchantedBow fkbm.options matches 1 if score Difficulty fkbm.options matches 2 if entity @s[tag=fkbm.illusioner.enchantedbow] run data merge entity @s {HandItems:[{id:"minecraft:bow",Count:1b,tag:{Enchantments:[{id:"minecraft:power",lvl:2s},{id:"minecraft:punch",lvl:2s}]}}]}
execute if score IllusionerEnchantedBow fkbm.options matches 1 if score Difficulty fkbm.options matches 3 if entity @s[tag=fkbm.illusioner.enchantedbow] run data merge entity @s {HandItems:[{id:"minecraft:bow",Count:1b,tag:{Enchantments:[{id:"minecraft:power",lvl:3s},{id:"minecraft:punch",lvl:3s}]}}]}
scoreboard players set @s[tag=fkbm.illusioner.heal] fkbm.cd 0

tag @s add fkbm.touched