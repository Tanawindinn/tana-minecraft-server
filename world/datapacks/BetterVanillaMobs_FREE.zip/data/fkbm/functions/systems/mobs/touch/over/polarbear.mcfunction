# easy
execute if score Difficulty fkbm.options matches 1 if predicate fktool:rng/50 run tag @s add fkbm.polarbear.angry
execute if score Difficulty fkbm.options matches 1 unless predicate fkbm:mobs/is_baby run data merge entity @s {Health:40f,Attributes:[{Name:generic.max_health,Base:40},{Name:generic.armor,Base:4},{Name:generic.movement_speed,Base:0.28},{Name:generic.follow_range,Base:50},{Name:generic.knockback_resistance,Base:1.00}]}
execute if score Difficulty fkbm.options matches 1 if predicate fkbm:mobs/is_baby run data merge entity @s {Health:20f,Attributes:[{Name:generic.max_health,Base:20},{Name:generic.armor,Base:4},{Name:generic.movement_speed,Base:0.24},{Name:generic.follow_range,Base:50},{Name:generic.knockback_resistance,Base:1.00}]}

# normal
execute if score Difficulty fkbm.options matches 2 if predicate fktool:rng/75 run tag @s add fkbm.polarbear.angry
execute if score Difficulty fkbm.options matches 2 unless predicate fkbm:mobs/is_baby run data merge entity @s {Health:60f,Attributes:[{Name:generic.max_health,Base:60},{Name:generic.armor,Base:6},{Name:generic.movement_speed,Base:0.30},{Name:generic.follow_range,Base:50},{Name:generic.knockback_resistance,Base:1.00}]}
execute if score Difficulty fkbm.options matches 2 if predicate fkbm:mobs/is_baby run data merge entity @s {Health:30f,Attributes:[{Name:generic.max_health,Base:30},{Name:generic.armor,Base:6},{Name:generic.movement_speed,Base:0.26},{Name:generic.follow_range,Base:50},{Name:generic.knockback_resistance,Base:1.00}]}

# hard
execute if score Difficulty fkbm.options matches 3 if predicate fktool:rng/95 run tag @s add fkbm.polarbear.angry
execute if score Difficulty fkbm.options matches 3 unless predicate fkbm:mobs/is_baby run data merge entity @s {Health:80f,Attributes:[{Name:generic.max_health,Base:80},{Name:generic.armor,Base:8},{Name:generic.movement_speed,Base:0.32},{Name:generic.follow_range,Base:50},{Name:generic.knockback_resistance,Base:1.00}]}
execute if score Difficulty fkbm.options matches 3 if predicate fkbm:mobs/is_baby run data merge entity @s {Health:40f,Attributes:[{Name:generic.max_health,Base:40},{Name:generic.armor,Base:8},{Name:generic.movement_speed,Base:0.28},{Name:generic.follow_range,Base:50},{Name:generic.knockback_resistance,Base:1.00}]}

# shared
tag @s[tag=fkbm.baby] remove fkbm.baby
execute if predicate fkbm:mobs/is_baby run tag @s add fkbm.baby

tag @s add fkbm.touched