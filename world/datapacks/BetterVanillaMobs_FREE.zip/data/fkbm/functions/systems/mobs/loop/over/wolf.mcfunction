# angry
execute if score WolfAngry fkbm.options matches 1 as @s[tag=fkbm.wolf.angry] unless data entity @s Owner if entity @p[distance=..12,gamemode=!creative,gamemode=!spectator] run data merge entity @s {AngerTime:100}
execute if score WolfAngry fkbm.options matches 1 if score Difficulty fkbm.options matches 1 as @s[tag=fkbm.wolf.angry] unless data entity @s Owner if entity @p[distance=..3,gamemode=!creative,gamemode=!spectator] if predicate fktool:rng/50 run data modify entity @s AngryAt set from entity @p[distance=..3] UUID
execute if score WolfAngry fkbm.options matches 1 if score Difficulty fkbm.options matches 2 as @s[tag=fkbm.wolf.angry] unless data entity @s Owner if entity @p[distance=..3,gamemode=!creative,gamemode=!spectator] if predicate fktool:rng/75 run data modify entity @s AngryAt set from entity @p[distance=..3] UUID
execute if score WolfAngry fkbm.options matches 1 if score Difficulty fkbm.options matches 3 as @s[tag=fkbm.wolf.angry] unless data entity @s Owner if entity @p[distance=..3,gamemode=!creative,gamemode=!spectator] if predicate fktool:rng/95 run data modify entity @s AngryAt set from entity @p[distance=..3] UUID

tag @s add fkbm.looped