# easy
execute if score Difficulty fkbm.options matches 1 if predicate fktool:rng/30 run tag @s add fkbm.witch.regen
execute if score Difficulty fkbm.options matches 1 if predicate fktool:rng/50 run tag @s add fkbm.witch.summon
execute if score Difficulty fkbm.options matches 1 if predicate fktool:rng/25 run tag @s add fkbm.witch.zonya
execute if score Difficulty fkbm.options matches 1 run data merge entity @s {Health:30f,Attributes:[{Name:generic.max_health,Base:30},{Name:generic.armor,Base:4},{Name:generic.movement_speed,Base:0.30}]}

# normal
execute if score Difficulty fkbm.options matches 2 if predicate fktool:rng/60 run tag @s add fkbm.witch.regen
execute if score Difficulty fkbm.options matches 2 if predicate fktool:rng/75 run tag @s add fkbm.witch.summon
execute if score Difficulty fkbm.options matches 2 if predicate fktool:rng/50 run tag @s add fkbm.witch.zonya
execute if score Difficulty fkbm.options matches 2 run data merge entity @s {Health:40f,Attributes:[{Name:generic.max_health,Base:40},{Name:generic.armor,Base:8},{Name:generic.movement_speed,Base:0.32}]}

# hard
execute if score Difficulty fkbm.options matches 3 if predicate fktool:rng/95 run tag @s add fkbm.witch.regen
execute if score Difficulty fkbm.options matches 3 if predicate fktool:rng/95 run tag @s add fkbm.witch.summon
execute if score Difficulty fkbm.options matches 3 if predicate fktool:rng/75 run tag @s add fkbm.witch.zonya
execute if score Difficulty fkbm.options matches 3 run data merge entity @s {Health:50f,Attributes:[{Name:generic.max_health,Base:50},{Name:generic.armor,Base:12},{Name:generic.movement_speed,Base:0.34}]}

#shared
effect give @s[tag=fkbm.witch.regen] minecraft:regeneration 999999 1 true
scoreboard players set @s[tag=fkbm.witch.summon] fkbm.var 0
scoreboard players set @s[tag=fkbm.witch.zonya] fkbm.cd 0

tag @s add fkbm.touched