# rename
execute if score RenameAlphaMobs fkbm.options matches 1 if entity @s[tag=fkbm.slime.alpha] run data modify entity @s CustomName set value '{"text":"\\u2620 Alpha Slime \\u2620","color":"red"}'

# spe
attribute @s minecraft:generic.movement_speed modifier add 26061990-2023-02-10-003 fkbm.slime.alpha_speed 0.1 multiply_base
attribute @s minecraft:generic.max_health modifier add 26061990-2023-02-10-003 fkbm.slime.alpha_health 0.5 multiply
attribute @s minecraft:generic.knockback_resistance modifier add 26061990-2023-02-10-003 fkbm.slime.alpha_knockback_res 1 add
attribute @s minecraft:generic.attack_knockback modifier add 26061990-2023-02-10-003 fkbm.slime.alpha_knockback_atk 0.5 add
effect give @s minecraft:regeneration 999999 1 true
data merge entity @s {Size:6}