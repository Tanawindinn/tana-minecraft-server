# easy
execute if score Difficulty fkbm.options matches 1 if predicate fktool:rng/30 run tag @s add fkbm.pillager.firework
execute if score Difficulty fkbm.options matches 1 if predicate fktool:rng/20 run tag @s add fkbm.pillager.quickcharge
execute if score Difficulty fkbm.options matches 1 if predicate fktool:rng/15 run tag @s add fkbm.pillager.multishot
execute if score Difficulty fkbm.options matches 1 run data merge entity @s {Health:24f,Attributes:[{Name:generic.max_health,Base:24},{Name:generic.armor,Base:4},{Name:generic.movement_speed,Base:0.35}]}

# normal
execute if score Difficulty fkbm.options matches 2 if predicate fktool:rng/50 run tag @s add fkbm.pillager.firework
execute if score Difficulty fkbm.options matches 2 if predicate fktool:rng/40 run tag @s add fkbm.pillager.quickcharge
execute if score Difficulty fkbm.options matches 2 if predicate fktool:rng/30 run tag @s add fkbm.pillager.multishot
execute if score Difficulty fkbm.options matches 2 run data merge entity @s {Health:30f,Attributes:[{Name:generic.max_health,Base:30},{Name:generic.armor,Base:7},{Name:generic.movement_speed,Base:0.37}]}

# hard
execute if score Difficulty fkbm.options matches 3 if predicate fktool:rng/70 run tag @s add fkbm.pillager.firework
execute if score Difficulty fkbm.options matches 3 if predicate fktool:rng/60 run tag @s add fkbm.pillager.quickcharge
execute if score Difficulty fkbm.options matches 3 if predicate fktool:rng/45 run tag @s add fkbm.pillager.multishot
execute if score Difficulty fkbm.options matches 3 run data merge entity @s {Health:36f,Attributes:[{Name:generic.max_health,Base:36},{Name:generic.armor,Base:10},{Name:generic.movement_speed,Base:0.40}]}

# shared
execute if entity @s[tag=fkbm.pillager.quickcharge] run data modify entity @s HandItems[0].tag.Enchantments append value {id:"minecraft:quick_charge",lvl:2s}
execute if entity @s[tag=fkbm.pillager.multishot] run data modify entity @s HandItems[0].tag.Enchantments append value {id:"minecraft:multishot",lvl:1s}
scoreboard players set @s[tag=fkbm.pillager.firework] fkbm.cd 0

tag @s add fkbm.touched