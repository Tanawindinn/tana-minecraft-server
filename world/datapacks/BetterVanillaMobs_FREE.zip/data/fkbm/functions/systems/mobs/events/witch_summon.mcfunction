execute if predicate fktool:rng/90 run summon minecraft:slime ~ ~ ~ {Size:1,Tags:["fkbm.witch.minion"]}
execute if predicate fktool:rng/80 run summon minecraft:slime ~ ~ ~ {Size:1,Tags:["fkbm.witch.minion"]}
execute if predicate fktool:rng/40 run summon minecraft:pufferfish ~ ~ ~ {Tags:["fkbm.witch.minion"]}
execute if predicate fktool:rng/30 run summon minecraft:husk ~ ~ ~ {IsBaby:1b,Tags:["fkbm.witch.minion"]}
execute if predicate fktool:rng/20 run summon minecraft:cave_spider ~ ~ ~ {Tags:["fkbm.witch.minion"]}
execute if predicate fktool:rng/5 run summon minecraft:vex ~ ~ ~ {Tags:["fkbm.witch.minion"]}
execute if predicate fktool:rng/1 run summon minecraft:blaze ~ ~ ~ {Tags:["fkbm.witch.minion"]}

spreadplayers ~ ~ 1 3 false @e[tag=fkbm.witch.minion,distance=..4]
execute at @e[tag=fkbm.witch.minion,distance=..4] run particle minecraft:witch ~ ~.2 ~ .3 .3 .3 0 5
particle minecraft:dust_color_transition 1 0 1 2 0 0 0 ~ ~1 ~ .4 .5 .4 0 20
playsound minecraft:entity.witch.celebrate hostile @a[distance=..16] ~ ~1.6 ~ 1 .5

tag @e[tag=fkbm.witch.minion,distance=..4] remove fkbm.witch.minion
scoreboard players operation @s fkbm.var = WitchSummonCd fkbm.options