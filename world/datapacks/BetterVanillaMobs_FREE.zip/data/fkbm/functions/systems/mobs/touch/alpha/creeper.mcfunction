# rename
execute if score RenameAlphaMobs fkbm.options matches 1 run data modify entity @s CustomName set value '{"text":"\\u2620 Alpha Creeper \\u2620","color":"red"}'

# spe
attribute @s minecraft:generic.movement_speed modifier add 26061990-2023-02-13-002 fkbm.creeper.alpha_speed 0.2 multiply_base
data merge entity @s {powered:1b}
