# fusion
execute if score SlimeFusionCd fkbm.options matches 1.. if entity @s[tag=fkbm.slime.fusion] run scoreboard players operation @s fkbm.cd -= MobGameplayLatency fkbm.options
execute if score SlimeFusionCd fkbm.options matches 1.. if entity @s[tag=fkbm.slime.fusion,tag=!fkbm.slime.fusion.dead] if score @s fkbm.cd matches ..0 at @s run function fkbm:systems/mobs/events/slime_fusion
execute if score SlimeFusionCd fkbm.options matches 1.. if entity @s[tag=fkbm.slime.fusion] unless score @s fkbm.cd matches 0.. run scoreboard players operation @s fkbm.cd = SlimeFusionCd fkbm.options

tag @s add fkbm.looped