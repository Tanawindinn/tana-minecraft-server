# summon
execute if score WitchSummon fkbm.options matches 1 if entity @s[tag=fkbm.witch.summon,scores={fkbm.var=..0}] if entity @p[distance=..12,gamemode=!creative,gamemode=!spectator] unless entity @e[tag=fkbm.witch.minion,distance=..14] run function fkbm:systems/mobs/events/witch_summon
scoreboard players operation @s[tag=fkbm.witch.summon,scores={fkbm.var=1..}] fkbm.var -= MobGameplayLatency fkbm.options

# zonya
execute if score WitchZonya fkbm.options matches 1 if entity @s[tag=fkbm.witch.zonya] store result score #tmp fkbm.cd run data get entity @s Health
execute if score WitchZonya fkbm.options matches 1 if entity @s[tag=fkbm.witch.zonya] if score #tmp fkbm.cd matches ..16 if entity @s[scores={fkbm.cd=..0}] run function fkbm:systems/mobs/events/witch_zonya
scoreboard players operation @s[tag=fkbm.witch.zonya,scores={fkbm.cd=1..}] fkbm.cd -= MobGameplayLatency fkbm.options

tag @s add fkbm.looped