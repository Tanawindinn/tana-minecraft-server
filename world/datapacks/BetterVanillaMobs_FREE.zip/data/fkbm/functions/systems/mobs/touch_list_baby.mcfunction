execute if score OverTouch fkbm.options matches 1 at @a[scores={fkbm.dim=0}] run function fkbm:systems/mobs/touch/baby/baby_over
execute if score NetherTouch fkbm.options matches 1 at @a[scores={fkbm.dim=-1}] run function fkbm:systems/mobs/touch/baby/baby_nether
#execute if score EndTouch fkbm.options matches 1 at @a[scores={fkbm.dim=1}] run function fkbm:systems/mobs/touch/baby/baby_end