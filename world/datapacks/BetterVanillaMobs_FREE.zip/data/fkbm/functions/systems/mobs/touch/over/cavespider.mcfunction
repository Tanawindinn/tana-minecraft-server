# easy
execute if score Difficulty fkbm.options matches 1 if predicate fktool:rng/10 run tag @s add fkbm.cavespider.nausea
execute if score Difficulty fkbm.options matches 1 run data merge entity @s {Health:12f,Attributes:[{Name:generic.max_health,Base:12},{Name:generic.attack_damage,Base:2},{Name:generic.movement_speed,Base:0.30}]}

# normal
execute if score Difficulty fkbm.options matches 2 if predicate fktool:rng/20 run tag @s add fkbm.cavespider.nausea
execute if score Difficulty fkbm.options matches 2 run data merge entity @s {Health:18f,Attributes:[{Name:generic.max_health,Base:18},{Name:generic.attack_damage,Base:3},{Name:generic.movement_speed,Base:0.33}]}

# hard
execute if score Difficulty fkbm.options matches 3 if predicate fktool:rng/30 run tag @s add fkbm.cavespider.nausea
execute if score Difficulty fkbm.options matches 3 run data merge entity @s {Health:24f,Attributes:[{Name:generic.max_health,Base:24},{Name:generic.attack_damage,Base:4},{Name:generic.movement_speed,Base:0.36}]}

# shared
execute if score CavespiderCeiling fkbm.options matches 1 run team join fkbm.spider @s
execute if entity @s[tag=fkbm.spider.baby] run attribute @s minecraft:generic.max_health modifier add 26061990-2023-02-27-001 fkbm.spider.baby_heath -0.5 multiply

tag @s add fkbm.touched