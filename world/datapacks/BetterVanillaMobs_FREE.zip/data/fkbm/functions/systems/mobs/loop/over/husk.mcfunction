# break torch
execute if score HuskBreakTorch fkbm.options matches 1 if entity @s[tag=fkbm.husk.torch] if entity @p[distance=..24] run function fkbm:systems/mobs/events/break_torches

# break door
execute if score HuskBreakDoor fkbm.options matches 1 if entity @s[tag=fkbm.husk.door] if entity @p[distance=..8,gamemode=!creative,gamemode=!spectator] if predicate fktool:rng/25 if block ^ ^.2 ^.4 #fkbm:zombie_breakdoor run fill ^ ^.2 ^.4 ^ ^.2 ^.4 minecraft:air destroy

# break fence
execute if score HuskBreakFence fkbm.options matches 1 if entity @s[tag=fkbm.husk.fence] if entity @p[distance=..8,gamemode=!creative,gamemode=!spectator] if predicate fktool:rng/25 if block ^ ^.2 ^.9 #fkbm:zombie_breakfence run fill ^ ^.2 ^.9 ^ ^.2 ^.9 minecraft:air destroy

# hit slow
# see advancement

# regen
execute if score HuskPassiveRegenCd fkbm.options matches 1.. if entity @s[tag=fkbm.husk.regen] run scoreboard players operation @s fkbm.cd -= MobGameplayLatency fkbm.options
execute if score HuskPassiveRegenCd fkbm.options matches 1.. if entity @s[tag=fkbm.husk.regen] if score @s fkbm.cd matches ..0 run effect give @s minecraft:instant_damage 1 0 true
execute if score HuskPassiveRegenCd fkbm.options matches 1.. if entity @s[tag=fkbm.husk.regen] unless score @s fkbm.cd matches 0.. run scoreboard players operation @s fkbm.cd = HuskPassiveRegenCd fkbm.options

tag @s add fkbm.looped