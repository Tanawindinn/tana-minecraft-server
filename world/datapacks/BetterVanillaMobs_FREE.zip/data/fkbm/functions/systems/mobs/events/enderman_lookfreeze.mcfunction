advancement revoke @s only fkbm:mobs/enderman_lookfreeze

execute as @e[type=minecraft:enderman,tag=fkbm.enderman.lookfreeze,limit=1,sort=nearest,distance=..64] at @s anchored eyes facing entity @p eyes positioned ^ ^.25 ^.5 run particle minecraft:dragon_breath ^ ^.3 ^ 0 0 0 0 1 normal @a[distance=..64]
execute as @e[type=minecraft:enderman,tag=fkbm.enderman.lookfreeze,limit=1,sort=nearest,distance=..64] at @s anchored eyes facing entity @p eyes positioned ^ ^.25 ^.5 run particle minecraft:dragon_breath ^.2 ^.2 ^ 0 0 0 0 1 normal @a[distance=..64]
execute as @e[type=minecraft:enderman,tag=fkbm.enderman.lookfreeze,limit=1,sort=nearest,distance=..64] at @s anchored eyes facing entity @p eyes positioned ^ ^.25 ^.5 run particle minecraft:dragon_breath ^.3 ^ ^ 0 0 0 0 1 normal @a[distance=..64]
execute as @e[type=minecraft:enderman,tag=fkbm.enderman.lookfreeze,limit=1,sort=nearest,distance=..64] at @s anchored eyes facing entity @p eyes positioned ^ ^.25 ^.5 run particle minecraft:dragon_breath ^.2 ^-.2 ^ 0 0 0 0 1 normal @a[distance=..64]
execute as @e[type=minecraft:enderman,tag=fkbm.enderman.lookfreeze,limit=1,sort=nearest,distance=..64] at @s anchored eyes facing entity @p eyes positioned ^ ^.25 ^.5 run particle minecraft:dragon_breath ^ ^-.3 ^ 0 0 0 0 1 normal @a[distance=..64]
execute as @e[type=minecraft:enderman,tag=fkbm.enderman.lookfreeze,limit=1,sort=nearest,distance=..64] at @s anchored eyes facing entity @p eyes positioned ^ ^.25 ^.5 run particle minecraft:dragon_breath ^-.2 ^-.2 ^ 0 0 0 0 1 normal @a[distance=..64]
execute as @e[type=minecraft:enderman,tag=fkbm.enderman.lookfreeze,limit=1,sort=nearest,distance=..64] at @s anchored eyes facing entity @p eyes positioned ^ ^.25 ^.5 run particle minecraft:dragon_breath ^-.3 ^ ^ 0 0 0 0 1 normal @a[distance=..64]
execute as @e[type=minecraft:enderman,tag=fkbm.enderman.lookfreeze,limit=1,sort=nearest,distance=..64] at @s anchored eyes facing entity @p eyes positioned ^ ^.25 ^.5 run particle minecraft:dragon_breath ^-.2 ^.2 ^ 0 0 0 0 1 normal @a[distance=..64]

effect give @s minecraft:slowness 1 5 true
effect give @s minecraft:darkness 3 0 true