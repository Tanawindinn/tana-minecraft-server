# rename
execute if score RenameAlphaMobs fkbm.options matches 1 run data modify entity @s CustomName set value '{"text":"\\u2620 Alpha Spider \\u2620","color":"red"}'

# spe
team leave @s
attribute @s minecraft:generic.max_health modifier add 26061990-2023-02-13-002 fkbm.spider.alpha_health 0.5 multiply_base
attribute @s minecraft:generic.movement_speed modifier add 26061990-2023-02-13-002 fkbm.spider.alpha_speed 0.4 multiply_base
attribute @s minecraft:generic.armor modifier add 26061990-2023-02-13-002 fkbm.skeleton.alpha_armor 10 add
attribute @s minecraft:generic.attack_damage modifier add 26061990-2023-02-13-002 fkbm.skeleton.alpha_dmg 6 add
effect give @s minecraft:regeneration 999999 0 true
