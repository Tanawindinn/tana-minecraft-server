# cd buff
execute if score IllusionerCdBuff fkbm.options matches 1 if entity @s[tag=fkbm.illusioner.cdbuff] store result score #tmp fkbm.options run data get entity @s SpellTicks
execute if score IllusionerCdBuff fkbm.options matches 1 if entity @s[tag=fkbm.illusioner.cdbuff] if score Difficulty fkbm.options matches 1 if score #tmp fkbm.options matches 1.. run scoreboard players operation #tmp fkbm.options -= #3 fktool
execute if score IllusionerCdBuff fkbm.options matches 1 if entity @s[tag=fkbm.illusioner.cdbuff] if score Difficulty fkbm.options matches 2 if score #tmp fkbm.options matches 1.. run scoreboard players operation #tmp fkbm.options -= #6 fktool
execute if score IllusionerCdBuff fkbm.options matches 1 if entity @s[tag=fkbm.illusioner.cdbuff] if score Difficulty fkbm.options matches 3 if score #tmp fkbm.options matches 1.. run scoreboard players operation #tmp fkbm.options -= #10 fktool
execute if score IllusionerCdBuff fkbm.options matches 1 if entity @s[tag=fkbm.illusioner.cdbuff] store result storage fkbm:mobs/illusioner cd int 1 run scoreboard players get #tmp fkbm.options
execute if score IllusionerCdBuff fkbm.options matches 1 if entity @s[tag=fkbm.illusioner.cdbuff] run data modify entity @s SpellTicks set from storage fkbm:mobs/illusioner cd

# heal
execute if score IllusionerHealCd fkbm.options matches 1.. if entity @s[tag=fkbm.illusioner.heal] store result score #tmp fkbm.var run data get entity @s Health
execute if score IllusionerHealCd fkbm.options matches 1.. if entity @s[tag=fkbm.illusioner.heal] run scoreboard players operation @s[scores={fkbm.cd=1..}] fkbm.cd -= MobGameplayLatency fkbm.options
execute if score IllusionerHealCd fkbm.options matches 1.. if entity @s[tag=fkbm.illusioner.heal,tag=fkbm.illusioner.cdbuff] run scoreboard players operation @s[scores={fkbm.cd=1..}] fkbm.cd -= MobGameplayLatency fkbm.options
execute if score IllusionerHealCd fkbm.options matches 1.. if entity @s[tag=fkbm.illusioner.heal] if score #tmp fkbm.var matches ..28 if score @s fkbm.cd matches ..0 run function fkbm:systems/mobs/events/illusioner_heal

tag @s add fkbm.looped