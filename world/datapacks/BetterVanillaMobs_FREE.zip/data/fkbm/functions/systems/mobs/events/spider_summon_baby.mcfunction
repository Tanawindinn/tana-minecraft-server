# cocoon
fill ~-2 ~-1 ~-1 ~2 ~1 ~1 minecraft:cobweb replace #fkbm:spider_cocoon
fill ~-1 ~-2 ~-1 ~1 ~2 ~1 minecraft:cobweb replace #fkbm:spider_cocoon
fill ~-1 ~-1 ~-2 ~1 ~1 ~2 minecraft:cobweb replace #fkbm:spider_cocoon
fill ~ ~ ~ ~ ~ ~ minecraft:air replace minecraft:cobweb
effect give @s minecraft:slowness 999 9 true
effect give @s minecraft:resistance 30 2 true

# summon
function fktool:rng/get
execute if score Random fktool matches 00..100 run summon minecraft:cave_spider ~1 ~.2 ~ {Tags:["fkbm.spider.baby","fkbm.spider.baby.init"]}
execute if score Random fktool matches 00..080 run summon minecraft:cave_spider ~-1 ~.2 ~ {Tags:["fkbm.spider.baby","fkbm.spider.baby.init"]}
execute if score Random fktool matches 00..060 run summon minecraft:cave_spider ~ ~.2 ~1 {Tags:["fkbm.spider.baby","fkbm.spider.baby.init"]}
execute if score Random fktool matches 00..040 run summon minecraft:cave_spider ~ ~.2 ~-1 {Tags:["fkbm.spider.baby","fkbm.spider.baby.init"]}
execute if score Random fktool matches 00..020 run summon minecraft:cave_spider ~ ~1.2 ~ {Tags:["fkbm.spider.baby","fkbm.spider.baby.init"]}
execute as @e[type=minecraft:cave_spider,tag=fkbm.spider.baby.init,distance=..1] run function fkbm:systems/mobs/touch/over/cavespider
tag @e[type=minecraft:cave_spider,tag=fkbm.spider.baby.init,distance=..1] remove fkbm.spider.baby.init

# fx
particle minecraft:block cobweb ~ ~1 ~ 2 2 2 .1 99
playsound minecraft:entity.spider.step hostile @a[distance=..16] ^ ^ ^2 3 .5 .5

# cd
tag @s add fkbm.spider.summoned
scoreboard players operation @s fkbm.cd = SpiderMommyCd fkbm.options