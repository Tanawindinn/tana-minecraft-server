# root
execute if score Difficulty fkbm.options matches 1 run effect give @p[distance=..10,gamemode=!creative,gamemode=!spectator] minecraft:slowness 1 1 false
execute if score Difficulty fkbm.options matches 2 run effect give @p[distance=..10,gamemode=!creative,gamemode=!spectator] minecraft:slowness 1 2 false
execute if score Difficulty fkbm.options matches 3 run effect give @p[distance=..10,gamemode=!creative,gamemode=!spectator] minecraft:slowness 1 3 false

# fx
particle minecraft:wax_off ~ ~2.2 ~ .2 .1 .2 0.1 8
playsound minecraft:entity.evoker.cast_spell hostile @a[distance=..16] ~ ~ ~ 2 1.5

scoreboard players operation @s fkbm.var = EvokerRootCd fkbm.options