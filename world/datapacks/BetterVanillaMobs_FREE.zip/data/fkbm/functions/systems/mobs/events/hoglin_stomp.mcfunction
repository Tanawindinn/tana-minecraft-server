effect give @s minecraft:slowness 1 6 true
effect give @s minecraft:resistance 1 3 true

playsound minecraft:entity.hoglin.angry hostile @a[distance=..16] ~ ~ ~ 3 .5
execute if predicate fktool:location/in_over run particle minecraft:block dirt ~ ~.2 ~ .5 .1 .5 0 50
execute if predicate fktool:location/in_nether run particle minecraft:block netherrack ~ ~.2 ~ .5 .1 .5 0 50

tag @s add fkbm.hoglin.stomp.step1
scoreboard players operation @s fkbm.cd = HoglinStompCd fkbm.options

execute if score Difficulty fkbm.options matches 1 run schedule function fkbm:systems/mobs/events/hoglin_stomp_1 40t
execute if score Difficulty fkbm.options matches 2 run schedule function fkbm:systems/mobs/events/hoglin_stomp_1 30t
execute if score Difficulty fkbm.options matches 3 run schedule function fkbm:systems/mobs/events/hoglin_stomp_1 20t