# stomp
execute if score HoglinStomp fkbm.options matches 1 if entity @s[tag=fkbm.hoglin.stomp,scores={fkbm.cd=..0}] if entity @p[distance=..3,gamemode=!creative,gamemode=!spectator] run function fkbm:systems/mobs/events/hoglin_stomp
scoreboard players operation @s[tag=fkbm.hoglin.stomp,scores={fkbm.cd=1..}] fkbm.cd -= MobGameplayLatency fkbm.options

tag @s add fkbm.looped