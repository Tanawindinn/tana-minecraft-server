# angry
execute if score PolarbearAngry fkbm.options matches 1 as @s[tag=fkbm.polarbear.angry] if entity @p[gamemode=!creative,gamemode=!spectator,distance=..24] run data merge entity @s {AngerTime:100}
execute if score PolarbearAngry fkbm.options matches 1 as @s[tag=fkbm.polarbear.angry] if entity @p[gamemode=!creative,gamemode=!spectator,distance=..16] run data modify entity @s AngryAt set from entity @p[gamemode=!creative,gamemode=!spectator,distance=..16] UUID

tag @s add fkbm.looped