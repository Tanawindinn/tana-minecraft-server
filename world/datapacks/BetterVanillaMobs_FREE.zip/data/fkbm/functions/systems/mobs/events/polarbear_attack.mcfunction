execute if entity @p[gamemode=!creative,gamemode=!spectator,distance=..48] if entity @s[nbt={AngerTime:0}] run particle minecraft:dust_color_transition .8 .1 .1 2 .8 .2 .2 ~ ~1 ~ 1 1 1 0 20
execute if entity @p[gamemode=!creative,gamemode=!spectator,distance=..48] if entity @s[nbt={AngerTime:0}] run playsound minecraft:entity.polar_bear.warning hostile @a[distance=..64] ~ ~ ~ 2 .8 .5

execute if entity @p[gamemode=!creative,gamemode=!spectator,distance=..48] run data merge entity @s {AngerTime:200}
execute if entity @p[gamemode=!creative,gamemode=!spectator,distance=..48] run data modify entity @s AngryAt set from entity @p[gamemode=!creative,gamemode=!spectator,distance=..48] UUID