advancement revoke @s only fkbm:mobs/vindicator_rage

# fx
execute as @e[type=minecraft:vindicator,tag=fkbm.vindicator.rage,distance=..8,limit=1] at @s run playsound minecraft:entity.vindicator.ambient hostile @a[distance=..16] ~ ~ ~ 3 .8 .2
execute as @e[type=minecraft:vindicator,tag=fkbm.vindicator.rage,distance=..8,limit=1] at @s run playsound minecraft:entity.vindicator.death hostile @a[distance=..16] ~ ~ ~ 3 .5 .2
execute as @e[type=minecraft:vindicator,tag=fkbm.vindicator.rage,distance=..8,limit=1] at @s run particle minecraft:angry_villager ~ ~1.8 ~ .2 .1 .2 0 3

# effect
effect give @e[type=minecraft:vindicator,tag=fkbm.vindicator.rage,distance=..8,limit=1] minecraft:poison 8 0 false
effect give @e[type=minecraft:vindicator,tag=fkbm.vindicator.rage,distance=..8,limit=1] minecraft:speed 8 0 false
#execute if score Difficulty fkbm.options matches 1 run effect give @e[type=minecraft:vindicator,tag=fkbm.vindicator.rage,distance=..8,limit=1] minecraft:strength 2 0 false
execute if score Difficulty fkbm.options matches 2 run effect give @e[type=minecraft:vindicator,tag=fkbm.vindicator.rage,distance=..8,limit=1] minecraft:strength 4 0 false
execute if score Difficulty fkbm.options matches 3 run effect give @e[type=minecraft:vindicator,tag=fkbm.vindicator.rage,distance=..8,limit=1] minecraft:strength 8 0 false