# load fireworks in crossbow
execute if entity @s[tag=!fkbm.pillager.multishot] run data modify entity @s HandItems[0].tag merge value {Charged:1b,ChargedProjectiles:[{},{id:"minecraft:firework_rocket",Count:1b,tag:{Fireworks:{Explosions:[{Type:0,Flicker:1b,Colors:[I;61183,48127],FadeColors:[I;2372351]}]}}},{}]}
execute if entity @s[tag=fkbm.pillager.multishot] run data modify entity @s HandItems[0].tag merge value {Charged:1b,ChargedProjectiles:[{id:"minecraft:firework_rocket",Count:1b,tag:{Fireworks:{Explosions:[{Type:0,Flicker:1b,Colors:[I;61183,48127],FadeColors:[I;2372351]}]}}},{id:"minecraft:firework_rocket",Count:1b,tag:{Fireworks:{Explosions:[{Type:0,Flicker:1b,Colors:[I;61183,48127],FadeColors:[I;2372351]}]}}},{id:"minecraft:firework_rocket",Count:1b,tag:{Fireworks:{Explosions:[{Type:0,Flicker:1b,Colors:[I;61183,48127],FadeColors:[I;2372351]}]}}}]}

# cd
scoreboard players operation @s fkbm.cd = PillagerFireworkRocketCd fkbm.options
execute if score Difficulty fkbm.options matches 1 run scoreboard players operation @s fkbm.cd /= #1 fktool
execute if score Difficulty fkbm.options matches 2 run scoreboard players operation @s fkbm.cd /= #2 fktool
execute if score Difficulty fkbm.options matches 3 run scoreboard players operation @s fkbm.cd /= #3 fktool
