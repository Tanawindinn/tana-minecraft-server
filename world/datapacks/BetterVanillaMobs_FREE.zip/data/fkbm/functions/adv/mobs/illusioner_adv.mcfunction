advancement revoke @s only fkbm:mobs/illusioner_chance_1.17
advancement revoke @s only fkbm:mobs/illusioner_chance_1.19
tag @s add fkbm.illusioner_chance
schedule function fkbm:adv/mobs/illusioner_adv_1t 1t