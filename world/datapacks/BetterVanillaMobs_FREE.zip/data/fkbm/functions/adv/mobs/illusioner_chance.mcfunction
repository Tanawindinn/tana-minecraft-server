tag @s add fkbm.illusioner.chance
function fktool:rng/get
execute if score Random fktool <= IllusionerSpawnChance fkbm.options unless entity @e[type=minecraft:illusioner,distance=..64,limit=1] run function fkbm:systems/mobs/events/illusioner_spawn