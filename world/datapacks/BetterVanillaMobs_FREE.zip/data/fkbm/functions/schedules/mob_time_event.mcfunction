# wolf night attack
execute if score Difficulty fkbm.options matches 1.. if score WolfNightAttack fkbm.options matches 1 if predicate fktool:time/period/night as @e[type=minecraft:wolf,tag=fkbm.wolf.angry] at @s unless data entity @s Owner run function fkbm:systems/mobs/events/wolf_night_attack

# polar bear attack
execute if score Difficulty fkbm.options matches 1.. if score PolarbearAngry fkbm.options matches 1 as @e[type=minecraft:polar_bear,tag=fkbm.polarbear.angry] at @s run function fkbm:systems/mobs/events/polarbear_attack

# skeleton arrows pickup
execute if score Difficulty fkbm.options matches 1.. if score EntityArrowPickup fkbm.options matches 1 as @e[type=minecraft:arrow] run data modify entity @s pickup set value 1b

schedule function fkbm:schedules/mob_time_event 10s