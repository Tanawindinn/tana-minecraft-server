

schedule function fkbm:schedules/cooldowns 1s