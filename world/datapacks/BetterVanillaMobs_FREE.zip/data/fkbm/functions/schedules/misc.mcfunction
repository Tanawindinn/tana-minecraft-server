# clamp base difficulty
execute if score BaseDifficulty fkbm.options matches ..-1 run scoreboard players set BaseDifficulty fkbm.options 4
execute if score BaseDifficulty fkbm.options matches 5.. run scoreboard players set BaseDifficulty fkbm.options 4

# chose difficulty
execute if score BaseDifficulty fkbm.options matches 0 run scoreboard players set Difficulty fkbm.options 0
execute if score BaseDifficulty fkbm.options matches 1 run scoreboard players set Difficulty fkbm.options 1
execute if score BaseDifficulty fkbm.options matches 2 run scoreboard players set Difficulty fkbm.options 2
execute if score BaseDifficulty fkbm.options matches 3 run scoreboard players set Difficulty fkbm.options 3
execute if score BaseDifficulty fkbm.options matches 4 run function fktool:difficulty/get
execute if score BaseDifficulty fkbm.options matches 4 run scoreboard players operation Difficulty fkbm.options = Difficulty fktool

schedule function fkbm:schedules/misc 15s