function fkbm:schedules/misc
function fkbm:schedules/mob_touch
function fkbm:schedules/mob_touch_baby
function fkbm:schedules/mob_gameplay
function fkbm:schedules/mob_time_event
function fkbm:schedules/cleaner
#function fkbm:schedules/cooldowns