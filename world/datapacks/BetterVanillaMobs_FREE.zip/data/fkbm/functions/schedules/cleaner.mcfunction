# fkbm.cd score cleaning (+ init mobs using this score)
scoreboard objectives remove fkbm.cd
scoreboard objectives add fkbm.cd dummy {"text":"fkbm.cd","color":"#80a0b4"}
scoreboard players set @e[type=minecraft:enderman,tag=fkbm.enderman.lookbreak] fkbm.cd 0
scoreboard players set @e[type=minecraft:evoker,tag=fkbm.evoker.groupregen] fkbm.cd 0
scoreboard players set @e[type=minecraft:hoglin,tag=fkbm.hoglin.stomp] fkbm.cd 0
scoreboard players set @e[type=minecraft:illusioner,tag=fkbm.illusioner.heal] fkbm.cd 0
scoreboard players set @e[type=minecraft:pillager,tag=fkbm.pillager.firework] fkbm.cd 0
scoreboard players set @e[type=minecraft:skeleton,tag=fkbm.skeleton.shield] fkbm.cd 0
scoreboard players set @e[type=minecraft:spider,tag=fkbm.spider.mommy] fkbm.cd 0
scoreboard players set @e[type=minecraft:stray,tag=fkbm.stray.iceprison] fkbm.cd 0
scoreboard players set @e[type=minecraft:vex,tag=fkbm.vex.dodge] fkbm.cd 0
scoreboard players set @e[type=minecraft:witch,tag=fkbm.witch.zonya] fkbm.cd 0

# fkbm.var score cleaning (+ init mobs using this score)
scoreboard objectives remove fkbm.var
scoreboard objectives add fkbm.var dummy {"text":"fkbm.var","color":"#80a0b4"}
scoreboard players set @e[type=minecraft:enderman,tag=fkbm.enderman.vortex] fkbm.var 0
scoreboard players set @e[type=minecraft:evoker,tag=fkbm.evoker.root] fkbm.var 0
scoreboard players set @e[type=minecraft:witch,tag=fkbm.witch.summon] fkbm.var 0

# remaining markers
execute as @e[type=minecraft:marker,tag=fkbm.zombie.dig] at @s unless entity @p[distance=..10] run kill @s

# check compatibility
function fkbm:compatibility/checks

schedule function fkbm:schedules/cleaner 300s