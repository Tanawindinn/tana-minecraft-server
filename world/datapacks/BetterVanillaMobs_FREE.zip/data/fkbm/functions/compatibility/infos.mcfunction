execute if score Beasts_and_Monsters fkbm.compat matches 1 run function fkbm:compatibility/beasts_and_monsters/info
execute if score Mob_Captains fkbm.compat matches 1 run function fkbm:compatibility/mob_captains/info
execute if score Dungeon_Now_Loading fkbm.compat matches 1 run function fkbm:compatibility/dungeon_now_loading/info
execute if score RPG_Loot fkbm.compat matches 1 run function fkbm:compatibility/rpg_loot/info
execute if score Special_Mobs fkbm.compat matches 1 run function fkbm:compatibility/special_mobs/info
execute if score True_Survival fkbm.compat matches 1 run function fkbm:compatibility/true_survival/info
execute if score Vanilla_Mob_Bosses_Variants fkbm.compat matches 1 run function fkbm:compatibility/vanilla_mob_bosses_variants/info