function fkbm:compatibility/beasts_and_monsters/check
function fkbm:compatibility/mob_captains/check
function fkbm:compatibility/dungeon_now_loading/check
function fkbm:compatibility/rpg_loot/check
function fkbm:compatibility/special_mobs/check
function fkbm:compatibility/true_survival/check
function fkbm:compatibility/vanilla_mob_bosses_variants/check