execute if score Beasts_and_Monsters fkbm.compat matches 1 run function fkbm:compatibility/beasts_and_monsters/post_secure
execute if score Mob_Captains fkbm.compat matches 1 run function fkbm:compatibility/mob_captains/post_secure
execute if score Dungeon_Now_Loading fkbm.compat matches 1 run function fkbm:compatibility/dungeon_now_loading/post_secure
execute if score RPG_Loot fkbm.compat matches 1 run function fkbm:compatibility/rpg_loot/post_secure
execute if score Special_Mobs fkbm.compat matches 1 run function fkbm:compatibility/special_mobs/post_secure
execute if score True_Survival fkbm.compat matches 1 run function fkbm:compatibility/true_survival/post_secure
execute if score Vanilla_Mob_Bosses_Variants fkbm.compat matches 1 run function fkbm:compatibility/vanilla_mob_bosses_variants/post_secure