# Better Vanilla Mobs
A Minecraft datapack to add more challenge with vanilla monsters, making them faster, stronger and smarter. New behaviors and skills are given randomly to the mobs. Sometimes, a powerful ALPHA mob apears.

# Requires 
- Minecraft 1.20+

# Use
1. Download the package
2. Copy/paste the entire "BetterVanillaMobs/" archive in your "saves/your-map/datapacks/" folder.
3. Launch the game/server and play your map as you always do.

# Author
- Name : FunkyToc 
- Website : https://funkytoc.fr

# License
This work is licensed under the Creative Commons Attribution-NonCommercial-NoDerivatives 4.0 International License: http://creativecommons.org/licenses/by-nc-nd/4.0/

# Thanks
...
